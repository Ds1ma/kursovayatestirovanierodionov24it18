package shoppinglist;

import javax.swing.*;

public class Main {

    public static void main(String[] args) {
        // Установим системный стиль оформления — окно будет выглядеть нативно
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {
            // Если не получилось — останется стандартный вид
        }

        // Swing должен запускаться в потоке диспетчеризации событий
        SwingUtilities.invokeLater(MainFrame::new);
    }
}