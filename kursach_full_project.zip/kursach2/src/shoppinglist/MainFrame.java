package shoppinglist;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.TreeSet;

public class MainFrame extends JFrame {

    /** Базовые категории (пользователь может ввести и свою) */
    private static final String[] BASE_CATEGORIES = {
            Product.DEFAULT_CATEGORY, "Продукты", "Молочные продукты", "Овощи и фрукты",
            "Мясо и рыба", "Напитки", "Бытовая химия", "Одежда", "Другое"
    };

    private final DefaultListModel<Product> listModel = new DefaultListModel<>();
    private final JList<Product> productList = new JList<>(listModel);
    private final List<Product> products = new ArrayList<>();

    private final JTextField nameField = new JTextField(14);
    private final JTextField qtyField = new JTextField(4);
    private final JTextField priceField = new JTextField(6);
    private final JComboBox<String> categoryBox = new JComboBox<>(BASE_CATEGORIES);

    private final JTextField searchField = new JTextField(14);
    private final JComboBox<String> filterBox = new JComboBox<>();
    private final JCheckBox hideBoughtBox = new JCheckBox("Скрыть купленные");
    private final JComboBox<ProductFilter.SortMode> sortBox =
            new JComboBox<>(ProductFilter.SortMode.values());

    private final JLabel summaryLabel = new JLabel(" ");
    private final JLabel statusLabel = new JLabel("Готово");

    /** true, пока программа сама перестраивает список категорий фильтра */
    private boolean updatingFilter = false;

    public MainFrame() {
        super("🛒 Список покупок");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(980, 640);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(8, 8));

        categoryBox.setEditable(true);

        add(buildTopPanel(), BorderLayout.NORTH);
        add(buildCenterPanel(), BorderLayout.CENTER);
        add(buildBottomPanel(), BorderLayout.SOUTH);

        // Загружаем сохранённые данные
        products.addAll(StorageHelper.load());
        refreshList();

        setVisible(true);
    }

    // ============ Построение интерфейса ============

    /** Верхняя панель: ввод товара, поиск и сортировка */
    private JPanel buildTopPanel() {
        JPanel input = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 6));
        input.add(new JLabel("Название:"));
        input.add(nameField);
        input.add(new JLabel("Кол-во:"));
        input.add(qtyField);
        input.add(new JLabel("Цена, ₽:"));
        input.add(priceField);
        input.add(new JLabel("Категория:"));
        input.add(categoryBox);
        JButton addBtn = new JButton("Добавить");
        addBtn.addActionListener(e -> addProduct());
        input.add(addBtn);

        // Enter в любом поле ввода = добавить
        nameField.addActionListener(e -> addProduct());
        qtyField.addActionListener(e -> addProduct());
        priceField.addActionListener(e -> addProduct());

        JPanel view = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 6));
        view.add(new JLabel("Поиск:"));
        view.add(searchField);
        view.add(new JLabel("Показать:"));
        view.add(filterBox);
        view.add(new JLabel("Сортировка:"));
        view.add(sortBox);
        view.add(hideBoughtBox);

        // Любое изменение поиска, фильтра или сортировки сразу обновляет список
        searchField.getDocument().addDocumentListener(new DocumentListener() {
            @Override public void insertUpdate(DocumentEvent e) { refreshList(); }
            @Override public void removeUpdate(DocumentEvent e) { refreshList(); }
            @Override public void changedUpdate(DocumentEvent e) { refreshList(); }
        });
        filterBox.addActionListener(e -> {
            if (!updatingFilter) {
                refreshList();
            }
        });
        sortBox.addActionListener(e -> refreshList());
        hideBoughtBox.addActionListener(e -> refreshList());

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(new EmptyBorder(4, 4, 0, 4));
        panel.add(input);
        panel.add(view);
        return panel;
    }

    /** Центр: список товаров */
    private JScrollPane buildCenterPanel() {
        productList.setFont(new Font("Monospaced", Font.PLAIN, 14));
        productList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        productList.setCellRenderer(new ProductRenderer());

        // Двойной клик — переключить "куплено"
        productList.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent e) {
                if (e.getClickCount() == 2) {
                    toggleBought();
                }
            }
        });

        // Клавиша Delete — удалить выделенный товар
        productList.getInputMap().put(KeyStroke.getKeyStroke("DELETE"), "deleteProduct");
        productList.getActionMap().put("deleteProduct", new AbstractAction() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent e) {
                deleteSelected();
            }
        });

        return new JScrollPane(productList);
    }

    /** Нижняя панель: кнопки управления и строки состояния */
    private JPanel buildBottomPanel() {
        JPanel wrapper = new JPanel(new BorderLayout());

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 8));
        buttons.add(makeButton("Отметить купленным", e -> toggleBought()));
        buttons.add(makeButton("Редактировать", e -> editSelected()));
        buttons.add(makeButton("Удалить", e -> deleteSelected()));
        buttons.add(makeButton("Очистить всё", e -> clearAll()));
        buttons.add(makeButton("Сохранить", e -> {
            StorageHelper.save(products);
            setStatus("Список сохранён в файл products.dat");
        }));
        buttons.add(makeButton("Экспорт", e -> exportToFile()));
        buttons.add(makeButton("Импорт", e -> importFromFile()));
        buttons.add(makeButton("Статистика", e -> showStatistics()));

        summaryLabel.setBorder(new EmptyBorder(2, 10, 0, 10));
        statusLabel.setBorder(new EmptyBorder(2, 10, 8, 10));
        JPanel labels = new JPanel(new GridLayout(2, 1));
        labels.add(summaryLabel);
        labels.add(statusLabel);

        wrapper.add(buttons, BorderLayout.NORTH);
        wrapper.add(labels, BorderLayout.SOUTH);
        return wrapper;
    }

    private JButton makeButton(String text, java.awt.event.ActionListener action) {
        JButton button = new JButton(text);
        button.addActionListener(action);
        return button;
    }

    // ============ ЛОГИКА С try-catch ============

    /** Добавление товара */
    private void addProduct() {
        try {
            Product product = ProductService.create(products, nameField.getText(),
                    qtyField.getText(), priceField.getText(), categoryText());

            products.add(product);
            StorageHelper.save(products);

            nameField.setText("");
            qtyField.setText("");
            priceField.setText("");
            nameField.requestFocus();

            refreshList();
            setStatus("Добавлено: " + product);

        } catch (IllegalArgumentException | IllegalStateException e) {
            showError(e.getMessage());
        } catch (Exception e) {
            showError("Неизвестная ошибка: " + e.getMessage());
        }
    }

    /** Переключить статус "куплено" у выделенного товара */
    private void toggleBought() {
        try {
            Product p = productList.getSelectedValue();
            if (p == null) {
                throw new IllegalStateException("Сначала выберите товар в списке!");
            }
            p.setBought(!p.isBought());
            StorageHelper.save(products);

            refreshList();
            productList.setSelectedValue(p, true);

            setStatus(p.isBought()
                    ? "Отмечено купленным: " + p.getName()
                    : "Снята отметка: " + p.getName());

        } catch (Exception e) {
            showError(e.getMessage());
        }
    }

    /** Изменить выделенный товар в окне редактирования */
    private void editSelected() {
        try {
            Product p = productList.getSelectedValue();
            if (p == null) {
                throw new IllegalStateException("Сначала выберите товар для редактирования!");
            }
            String name = p.getName();
            String qty = String.valueOf(p.getQuantity());
            String price = p.getPrice() > 0 ? String.format(Locale.US, "%.2f", p.getPrice()) : "";
            String category = p.getCategory();

            // Окно открывается заново, пока данные неверны или пользователь не нажмёт «Отмена»
            while (true) {
                JTextField nameEdit = new JTextField(name, 20);
                JTextField qtyEdit = new JTextField(qty, 20);
                JTextField priceEdit = new JTextField(price, 20);
                JComboBox<String> categoryEdit = new JComboBox<>();
                categoryEdit.setEditable(true);
                for (int i = 0; i < categoryBox.getItemCount(); i++) {
                    categoryEdit.addItem(categoryBox.getItemAt(i));
                }
                categoryEdit.setSelectedItem(category);

                JPanel panel = new JPanel(new GridLayout(0, 2, 6, 6));
                panel.add(new JLabel("Название:"));
                panel.add(nameEdit);
                panel.add(new JLabel("Количество:"));
                panel.add(qtyEdit);
                panel.add(new JLabel("Цена, ₽:"));
                panel.add(priceEdit);
                panel.add(new JLabel("Категория:"));
                panel.add(categoryEdit);

                int answer = JOptionPane.showConfirmDialog(this, panel, "Редактирование товара",
                        JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
                if (answer != JOptionPane.OK_OPTION) {
                    return;
                }
                name = nameEdit.getText();
                qty = qtyEdit.getText();
                price = priceEdit.getText();
                Object item = categoryEdit.getEditor().getItem();
                category = item == null ? "" : item.toString();

                try {
                    ProductService.update(p, products, name, qty, price, category);
                    break;
                } catch (IllegalArgumentException | IllegalStateException e) {
                    showError(e.getMessage());
                }
            }

            StorageHelper.save(products);
            refreshList();
            productList.setSelectedValue(p, true);
            setStatus("Изменено: " + p);

        } catch (Exception e) {
            showError(e.getMessage());
        }
    }

    /** Удалить выделенный товар */
    private void deleteSelected() {
        try {
            Product p = productList.getSelectedValue();
            if (p == null) {
                throw new IllegalStateException("Сначала выберите товар для удаления!");
            }
            products.remove(p);
            StorageHelper.save(products);
            refreshList();
            setStatus("Удалено: " + p.getName());
        } catch (Exception e) {
            showError(e.getMessage());
        }
    }

    /** Очистить весь список (с подтверждением) */
    private void clearAll() {
        try {
            if (products.isEmpty()) {
                throw new IllegalStateException("Список уже пуст!");
            }
            int answer = JOptionPane.showConfirmDialog(
                    this,
                    "Удалить все товары (" + products.size() + " шт.)?",
                    "Подтверждение",
                    JOptionPane.YES_NO_OPTION
            );
            if (answer == JOptionPane.YES_OPTION) {
                products.clear();
                StorageHelper.save(products);
                refreshList();
                setStatus("Список очищен.");
            }
        } catch (Exception e) {
            showError(e.getMessage());
        }
    }

    /** Показать окно со статистикой */
    private void showStatistics() {
        JOptionPane.showMessageDialog(this, new ShoppingStats(products).report(),
                "Статистика", JOptionPane.INFORMATION_MESSAGE);
    }

    // ============ Экспорт и импорт ============

    private void exportToFile() {
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Экспорт списка в файл");
        chooser.setSelectedFile(new File("список_покупок.csv"));
        chooser.setFileFilter(new FileNameExtensionFilter("Файлы CSV (*.csv)", "csv"));
        if (chooser.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) {
            return;
        }
        File file = chooser.getSelectedFile();
        if (!file.getName().toLowerCase(Locale.ROOT).endsWith(".csv")) {
            file = new File(file.getPath() + ".csv");
        }
        exportFile(file);
    }

    private void importFromFile() {
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Импорт списка из файла");
        chooser.setFileFilter(new FileNameExtensionFilter("Файлы CSV (*.csv)", "csv"));
        if (chooser.showOpenDialog(this) != JFileChooser.APPROVE_OPTION) {
            return;
        }
        importFile(chooser.getSelectedFile());
    }

    /** Записывает список в указанный файл CSV */
    void exportFile(File file) {
        try {
            CsvHelper.export(products, file);
            setStatus("Экспортировано товаров: " + products.size() + " (" + file.getName() + ")");
        } catch (IOException e) {
            showError("Не удалось записать файл: " + e.getMessage());
        }
    }

    /** Добавляет в список товары из файла CSV; товары с уже имеющимися названиями пропускаются */
    void importFile(File file) {
        try {
            List<Product> loaded = CsvHelper.importFrom(file);
            int added = 0;
            int skipped = 0;
            for (Product p : loaded) {
                try {
                    ProductService.checkDuplicate(products, p.getName(), null);
                    products.add(p);
                    added++;
                } catch (IllegalStateException e) {
                    skipped++;
                }
            }
            StorageHelper.save(products);
            refreshList();
            setStatus("Импортировано товаров: " + added + ", пропущено дубликатов: " + skipped);
        } catch (IOException e) {
            showError("Не удалось прочитать файл: " + e.getMessage());
        } catch (IllegalArgumentException e) {
            showError("Ошибка в файле. " + e.getMessage());
        }
    }

    // ============ Вспомогательные методы ============

    /** Текст из поля категории (в том числе только что введённый вручную) */
    private String categoryText() {
        Object item = categoryBox.getEditor().getItem();
        return item == null ? "" : item.toString();
    }

    /** Обновить отображение списка с учётом поиска, фильтра и сортировки */
    private void refreshList() {
        Product selected = productList.getSelectedValue();
        updateCategoryLists();

        List<Product> visible = ProductFilter.apply(
                products,
                searchField.getText(),
                (String) filterBox.getSelectedItem(),
                hideBoughtBox.isSelected(),
                (ProductFilter.SortMode) sortBox.getSelectedItem());

        listModel.clear();
        for (Product p : visible) {
            listModel.addElement(p);
        }
        if (selected != null && visible.contains(selected)) {
            productList.setSelectedValue(selected, true);
        }
        updateStatusCounter();
    }

    /** Приводит списки категорий в соответствие с товарами: в фильтре — только существующие */
    private void updateCategoryLists() {
        TreeSet<String> categories = new TreeSet<>(String.CASE_INSENSITIVE_ORDER);
        for (Product p : products) {
            categories.add(p.getCategory());
        }

        // Фильтр перестраивается только если набор категорий изменился
        List<String> wanted = new ArrayList<>();
        wanted.add(ProductFilter.ALL_CATEGORIES);
        wanted.addAll(categories);
        List<String> shown = new ArrayList<>();
        for (int i = 0; i < filterBox.getItemCount(); i++) {
            shown.add(filterBox.getItemAt(i));
        }

        if (!wanted.equals(shown)) {
            Object current = filterBox.getSelectedItem();
            updatingFilter = true;
            try {
                filterBox.removeAllItems();
                for (String item : wanted) {
                    filterBox.addItem(item);
                }
                int index = wanted.indexOf(current);
                filterBox.setSelectedIndex(index >= 0 ? index : 0);
            } finally {
                updatingFilter = false;
            }
        }

        // Новые категории (в том числе загруженные из файла) доступны и при вводе товара
        for (String c : categories) {
            boolean exists = false;
            for (int i = 0; i < categoryBox.getItemCount(); i++) {
                if (categoryBox.getItemAt(i).equalsIgnoreCase(c)) {
                    exists = true;
                    break;
                }
            }
            if (!exists) {
                String typed = categoryText();
                categoryBox.addItem(c);
                categoryBox.getEditor().setItem(typed);
            }
        }
    }

    /** Обновить строки состояния: счётчик и сумму */
    private void updateStatusCounter() {
        long bought = products.stream().filter(Product::isBought).count();
        setStatus("Куплено: " + bought + " из " + products.size());
        summaryLabel.setText(new ShoppingStats(products).summary());
    }

    private void setStatus(String text) {
        statusLabel.setText(text);
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(
                this,
                message,
                "Ошибка ввода",
                JOptionPane.ERROR_MESSAGE
        );
    }

    /** Отрисовка строки списка: отметка, название, количество, стоимость, категория */
    private static class ProductRenderer extends DefaultListCellRenderer {
        @Override
        public Component getListCellRendererComponent(JList<?> list, Object value, int index,
                                                      boolean isSelected, boolean cellHasFocus) {
            super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
            if (value instanceof Product) {
                Product p = (Product) value;
                String cost = p.getPrice() > 0 ? ShoppingStats.money(p.getTotal()) : "—";
                setText(String.format("%s  %-26s ×%-5d %12s   %s",
                        p.isBought() ? "[✓]" : "[ ]", p.getName(), p.getQuantity(), cost, p.getCategory()));
                if (!isSelected) {
                    setForeground(p.isBought() ? Color.GRAY : list.getForeground());
                }
            }
            return this;
        }
    }
}
