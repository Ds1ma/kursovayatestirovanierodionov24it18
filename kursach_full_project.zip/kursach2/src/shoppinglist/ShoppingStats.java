package shoppinglist;

import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;

/** Подсчёт статистики по списку: количество товаров и стоимость покупок */
public final class ShoppingStats {

    private final int totalCount;
    private final int boughtCount;
    private final double totalCost;
    private final double boughtCost;
    private final Map<String, Integer> countByCategory = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
    private final Map<String, Double> costByCategory = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);

    public ShoppingStats(List<Product> products) {
        int bought = 0;
        double total = 0;
        double spent = 0;
        for (Product p : products) {
            total += p.getTotal();
            if (p.isBought()) {
                bought++;
                spent += p.getTotal();
            }
            countByCategory.merge(p.getCategory(), 1, Integer::sum);
            costByCategory.merge(p.getCategory(), p.getTotal(), Double::sum);
        }
        this.totalCount = products.size();
        this.boughtCount = bought;
        this.totalCost = total;
        this.boughtCost = spent;
    }

    public int getTotalCount() { return totalCount; }
    public int getBoughtCount() { return boughtCount; }
    public int getRemainingCount() { return totalCount - boughtCount; }
    /** Стоимость всего списка */
    public double getTotalCost() { return totalCost; }
    /** Стоимость уже купленных товаров */
    public double getBoughtCost() { return boughtCost; }
    /** Сколько ещё предстоит потратить */
    public double getRemainingCost() { return totalCost - boughtCost; }
    public Map<String, Integer> getCountByCategory() { return countByCategory; }
    public Map<String, Double> getCostByCategory() { return costByCategory; }

    /** Денежная сумма в виде «120.50 ₽» */
    public static String money(double value) {
        return String.format(Locale.US, "%.2f ₽", value);
    }

    /** Краткая строка для главного окна */
    public String summary() {
        return "Товаров: " + totalCount + " | Куплено: " + boughtCount
                + " | Сумма: " + money(totalCost)
                + " | Осталось купить: " + money(getRemainingCost());
    }

    /** Подробный отчёт для окна «Статистика» */
    public String report() {
        StringBuilder sb = new StringBuilder();
        sb.append("Всего товаров: ").append(totalCount).append('\n');
        sb.append("Куплено: ").append(boughtCount).append(", осталось: ").append(getRemainingCount()).append('\n');
        sb.append("Стоимость списка: ").append(money(totalCost)).append('\n');
        sb.append("Потрачено: ").append(money(boughtCost)).append('\n');
        sb.append("Осталось потратить: ").append(money(getRemainingCost())).append('\n');
        if (!countByCategory.isEmpty()) {
            sb.append("\nПо категориям:\n");
            for (Map.Entry<String, Integer> e : countByCategory.entrySet()) {
                sb.append("  ").append(e.getKey()).append(": ").append(e.getValue())
                        .append(" шт., ").append(money(costByCategory.get(e.getKey()))).append('\n');
            }
        }
        return sb.toString();
    }
}
