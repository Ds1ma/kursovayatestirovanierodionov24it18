package shoppinglist;

import java.io.Serializable;

/** Позиция списка покупок */
public class Product implements Serializable {
    // Версия не меняется: файлы products.dat, сохранённые старой версией
    // программы, продолжают загружаться (новые поля получат значения по умолчанию)
    private static final long serialVersionUID = 1L;

    /** Категория по умолчанию */
    public static final String DEFAULT_CATEGORY = "Без категории";

    private String name;
    private int quantity;
    private boolean bought;
    private String category = DEFAULT_CATEGORY;
    private double price;   // цена за одну единицу, 0 — цена не указана

    public Product(String name, int quantity) {
        this(name, quantity, DEFAULT_CATEGORY, 0);
    }

    public Product(String name, int quantity, String category, double price) {
        this.name = name;
        this.quantity = quantity;
        this.bought = false;
        this.category = category;
        this.price = price;
    }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }

    public boolean isBought() { return bought; }
    public void setBought(boolean bought) { this.bought = bought; }

    /** Для товаров из старых файлов (где категории не было) вернёт категорию по умолчанию */
    public String getCategory() {
        return (category == null || category.isEmpty()) ? DEFAULT_CATEGORY : category;
    }
    public void setCategory(String category) { this.category = category; }

    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }

    /** Стоимость позиции: цена, умноженная на количество */
    public double getTotal() { return price * quantity; }

    @Override
    public String toString() {
        String mark = bought ? "[✓]" : "[ ]";
        return mark + " " + name + "  ×" + quantity;
    }
}
