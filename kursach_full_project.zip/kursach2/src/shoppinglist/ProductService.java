package shoppinglist;

import java.util.List;

/**
 * Правила проверки данных и создание/изменение товаров.
 * Класс не зависит от интерфейса, поэтому его можно проверять модульными тестами.
 * Все ошибки пользователя сообщаются исключением с понятным текстом.
 */
public final class ProductService {

    public static final int MAX_NAME_LENGTH = 50;
    public static final int MAX_QUANTITY = 9999;
    public static final double MAX_PRICE = 1_000_000;
    public static final int MAX_CATEGORY_LENGTH = 30;

    private ProductService() {
    }

    /** Название: не пустое и не длиннее 50 символов. Возвращает название без пробелов по краям */
    public static String checkName(String raw) {
        String name = raw == null ? "" : raw.trim();
        if (name.isEmpty()) {
            throw new IllegalArgumentException("Название товара не может быть пустым!");
        }
        if (name.length() > MAX_NAME_LENGTH) {
            throw new IllegalArgumentException("Название слишком длинное (макс. 50 символов).");
        }
        return name;
    }

    /** Количество: пустое поле означает 1, иначе целое число от 1 до 9999 */
    public static int parseQuantity(String raw) {
        String text = raw == null ? "" : raw.trim();
        if (text.isEmpty()) {
            return 1;
        }
        int quantity;
        try {
            quantity = Integer.parseInt(text);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Количество должно быть целым числом!");
        }
        if (quantity <= 0) {
            throw new IllegalArgumentException("Количество должно быть больше нуля!");
        }
        if (quantity > MAX_QUANTITY) {
            throw new IllegalArgumentException("Слишком большое количество (макс. 9999).");
        }
        return quantity;
    }

    /** Цена: пустое поле означает 0 (цена не указана), допускаются точка и запятая */
    public static double parsePrice(String raw) {
        String text = raw == null ? "" : raw.trim().replace(',', '.');
        if (text.isEmpty()) {
            return 0;
        }
        double price;
        try {
            price = Double.parseDouble(text);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Цена должна быть числом!");
        }
        if (Double.isNaN(price) || Double.isInfinite(price)) {
            throw new IllegalArgumentException("Цена должна быть числом!");
        }
        if (price < 0) {
            throw new IllegalArgumentException("Цена не может быть отрицательной!");
        }
        if (price > MAX_PRICE) {
            throw new IllegalArgumentException("Слишком большая цена (макс. 1000000).");
        }
        return Math.round(price * 100) / 100.0;   // до копеек
    }

    /** Категория: пустая означает «Без категории», длина не больше 30 символов */
    public static String checkCategory(String raw) {
        String category = raw == null ? "" : raw.trim();
        if (category.isEmpty()) {
            return Product.DEFAULT_CATEGORY;
        }
        if (category.length() > MAX_CATEGORY_LENGTH) {
            throw new IllegalArgumentException("Название категории слишком длинное (макс. 30 символов).");
        }
        return category;
    }

    /** Проверяет, что в списке нет другого товара с таким названием (без учёта регистра) */
    public static void checkDuplicate(List<Product> existing, String name, Product ignore) {
        for (Product p : existing) {
            if (p != ignore && p.getName().equalsIgnoreCase(name)) {
                throw new IllegalStateException("Товар \"" + name + "\" уже есть в списке!");
            }
        }
    }

    /** Проверяет все данные и создаёт новый товар (в список он не добавляется) */
    public static Product create(List<Product> existing, String name, String qty,
                                 String price, String category) {
        String checkedName = checkName(name);
        int quantity = parseQuantity(qty);
        double checkedPrice = parsePrice(price);
        String checkedCategory = checkCategory(category);
        checkDuplicate(existing, checkedName, null);
        return new Product(checkedName, quantity, checkedCategory, checkedPrice);
    }

    /**
     * Проверяет данные и изменяет товар. Если хотя бы одно значение
     * неверно, товар остаётся без изменений.
     */
    public static void update(Product product, List<Product> existing, String name, String qty,
                              String price, String category) {
        String checkedName = checkName(name);
        int quantity = parseQuantity(qty);
        double checkedPrice = parsePrice(price);
        String checkedCategory = checkCategory(category);
        checkDuplicate(existing, checkedName, product);
        product.setName(checkedName);
        product.setQuantity(quantity);
        product.setPrice(checkedPrice);
        product.setCategory(checkedCategory);
    }
}
