package shoppinglist;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/** Поиск, фильтрация по категории и сортировка списка товаров */
public final class ProductFilter {

    /** Значение фильтра «показывать все категории» */
    public static final String ALL_CATEGORIES = "Все категории";

    /** Способы сортировки списка */
    public enum SortMode {
        ADDED("По добавлению"),
        NAME("По названию"),
        CATEGORY("По категории"),
        UNBOUGHT_FIRST("Сначала некупленные"),
        PRICE_DESC("Сначала дорогие");

        private final String label;

        SortMode(String label) {
            this.label = label;
        }

        @Override
        public String toString() {
            return label;
        }
    }

    private ProductFilter() {
    }

    /**
     * Возвращает новый список: товары, название которых содержит query
     * (без учёта регистра), из нужной категории, при необходимости без
     * купленных, в заданном порядке. Исходный список не изменяется.
     */
    public static List<Product> apply(List<Product> source, String query, String category,
                                      boolean hideBought, SortMode mode) {
        String q = query == null ? "" : query.trim().toLowerCase(Locale.ROOT);
        boolean anyCategory = category == null || category.isEmpty()
                || ALL_CATEGORIES.equals(category);

        List<Product> result = new ArrayList<>();
        for (Product p : source) {
            if (!q.isEmpty() && !p.getName().toLowerCase(Locale.ROOT).contains(q)) {
                continue;
            }
            if (!anyCategory && !p.getCategory().equalsIgnoreCase(category)) {
                continue;
            }
            if (hideBought && p.isBought()) {
                continue;
            }
            result.add(p);
        }

        Comparator<Product> byName = Comparator.comparing(Product::getName, String.CASE_INSENSITIVE_ORDER);
        if (mode == SortMode.NAME) {
            result.sort(byName);
        } else if (mode == SortMode.CATEGORY) {
            result.sort(Comparator.comparing(Product::getCategory, String.CASE_INSENSITIVE_ORDER)
                    .thenComparing(byName));
        } else if (mode == SortMode.UNBOUGHT_FIRST) {
            result.sort(Comparator.comparing(Product::isBought));
        } else if (mode == SortMode.PRICE_DESC) {
            result.sort(Comparator.comparingDouble(Product::getPrice).reversed());
        }
        return result;   // при SortMode.ADDED порядок добавления не меняется
    }
}
