package shoppinglist;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class StorageHelper {
    private static final String FILE_NAME = "products.dat";

    /** Сохранить список товаров в файл */
    public static void save(List<Product> products) {
        try (ObjectOutputStream oos = new ObjectOutputStream(
                new FileOutputStream(FILE_NAME))) {
            oos.writeObject(new ArrayList<>(products));
        } catch (IOException e) {
            System.err.println("Ошибка сохранения: " + e.getMessage());
        }
    }

    /** Загрузить список товаров из файла */
    @SuppressWarnings("unchecked")
    public static List<Product> load() {
        File file = new File(FILE_NAME);
        if (!file.exists()) return new ArrayList<>();

        try (ObjectInputStream ois = new ObjectInputStream(
                new FileInputStream(file))) {
            Object obj = ois.readObject();
            if (obj instanceof List<?>) {
                return (List<Product>) obj;
            }
            return new ArrayList<>();
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Ошибка загрузки: " + e.getMessage());
            return new ArrayList<>();
        }
    }
}