package shoppinglist;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Экспорт и импорт списка в текстовый файл CSV (разделитель «;»,
 * кодировка UTF-8). Такой файл открывается в Excel и в любом текстовом редакторе.
 */
public final class CsvHelper {

    public static final String HEADER = "Название;Количество;Цена;Категория;Куплено";
    private static final char SEPARATOR = ';';
    private static final String BOM = "\uFEFF";

    private CsvHelper() {
    }

    /** Записывает список в файл */
    public static void export(List<Product> products, File file) throws IOException {
        StringBuilder sb = new StringBuilder(BOM).append(HEADER).append("\r\n");
        for (Product p : products) {
            sb.append(toLine(p)).append("\r\n");
        }
        Files.write(file.toPath(), sb.toString().getBytes(StandardCharsets.UTF_8));
    }

    /**
     * Читает список из файла. Каждая строка проверяется теми же правилами, что и
     * ввод в программе. При ошибке выбрасывается IllegalArgumentException
     * с номером строки.
     */
    public static List<Product> importFrom(File file) throws IOException {
        String content = new String(Files.readAllBytes(file.toPath()), StandardCharsets.UTF_8);
        if (content.startsWith(BOM)) {
            content = content.substring(1);
        }
        List<Product> result = new ArrayList<>();
        String[] lines = content.split("\r?\n");
        for (int i = 0; i < lines.length; i++) {
            String line = lines[i];
            if (line.trim().isEmpty() || (i == 0 && line.trim().equals(HEADER))) {
                continue;
            }
            try {
                result.add(fromLine(line));
            } catch (IllegalArgumentException e) {
                throw new IllegalArgumentException("Строка " + (i + 1) + ": " + e.getMessage());
            }
        }
        return result;
    }

    /** Превращает товар в строку файла */
    static String toLine(Product p) {
        return escape(p.getName()) + SEPARATOR
                + p.getQuantity() + SEPARATOR
                + String.format(Locale.US, "%.2f", p.getPrice()) + SEPARATOR
                + escape(p.getCategory()) + SEPARATOR
                + (p.isBought() ? "да" : "нет");
    }

    /** Разбирает строку файла в товар */
    static Product fromLine(String line) {
        List<String> f = split(line);
        if (f.size() != 5) {
            throw new IllegalArgumentException("ожидается 5 полей, найдено " + f.size());
        }
        Product p = new Product(ProductService.checkName(f.get(0)),
                ProductService.parseQuantity(f.get(1)),
                ProductService.checkCategory(f.get(3)),
                ProductService.parsePrice(f.get(2)));
        String bought = f.get(4).trim().toLowerCase(Locale.ROOT);
        if (bought.equals("да")) {
            p.setBought(true);
        } else if (!bought.equals("нет")) {
            throw new IllegalArgumentException("в поле «Куплено» должно быть «да» или «нет»");
        }
        return p;
    }

    private static String escape(String value) {
        if (value.indexOf(SEPARATOR) >= 0 || value.indexOf('"') >= 0
                || value.indexOf('\n') >= 0 || value.indexOf('\r') >= 0) {
            return "\"" + value.replace("\"", "\"\"") + "\"";
        }
        return value;
    }

    /** Делит строку по «;» с учётом полей в кавычках */
    static List<String> split(String line) {
        List<String> fields = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        boolean inQuotes = false;
        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);
            if (inQuotes) {
                if (c == '"') {
                    if (i + 1 < line.length() && line.charAt(i + 1) == '"') {
                        cur.append('"');
                        i++;
                    } else {
                        inQuotes = false;
                    }
                } else {
                    cur.append(c);
                }
            } else if (c == '"') {
                inQuotes = true;
            } else if (c == SEPARATOR) {
                fields.add(cur.toString());
                cur.setLength(0);
            } else {
                cur.append(c);
            }
        }
        if (inQuotes) {
            throw new IllegalArgumentException("не закрыты кавычки");
        }
        fields.add(cur.toString());
        return fields;
    }
}
