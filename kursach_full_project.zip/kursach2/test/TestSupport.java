package shoppinglist;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.lang.reflect.Field;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Predicate;

/**
 * Вспомогательные методы для тестов: работа с файлом products.dat,
 * поиск компонентов Swing, доступ к закрытым полям и автоматическое
 * закрытие модальных диалогов (JOptionPane) во время выполнения теста.
 */
final class TestSupport {

    /** Файл данных приложения (лежит в рабочем каталоге) */
    static final Path DATA_FILE = Paths.get("products.dat");
    private static final Path BACKUP_FILE = Paths.get("products.dat.test-backup");

    private TestSupport() {
    }

    // ---------- Файл данных ----------

    /** Прячет настоящий products.dat, чтобы тесты его не испортили */
    static void backupDataFile() throws IOException {
        if (Files.exists(BACKUP_FILE)) {
            // копия осталась от прерванного запуска и содержит оригинал
            Files.deleteIfExists(DATA_FILE);
        } else if (Files.exists(DATA_FILE)) {
            Files.move(DATA_FILE, BACKUP_FILE, StandardCopyOption.REPLACE_EXISTING);
        }
    }

    /** Возвращает настоящий products.dat на место */
    static void restoreDataFile() throws IOException {
        Files.deleteIfExists(DATA_FILE);
        if (Files.exists(BACKUP_FILE)) {
            Files.move(BACKUP_FILE, DATA_FILE, StandardCopyOption.REPLACE_EXISTING);
        }
    }

    // ---------- Компоненты Swing ----------

    static <T extends Component> T find(Container root, Class<T> type, Predicate<T> filter) {
        for (Component c : root.getComponents()) {
            if (type.isInstance(c) && filter.test(type.cast(c))) {
                return type.cast(c);
            }
            if (c instanceof Container) {
                T found = find((Container) c, type, filter);
                if (found != null) {
                    return found;
                }
            }
        }
        return null;
    }

    static JButton button(Container root, String text) {
        JButton b = find(root, JButton.class, x -> text.equals(x.getText()));
        if (b == null) {
            throw new AssertionError("Кнопка не найдена: " + text);
        }
        return b;
    }

    /** Читает закрытое поле объекта (например, nameField у MainFrame) */
    static Object field(Object target, String name) throws Exception {
        Field f = target.getClass().getDeclaredField(name);
        f.setAccessible(true);
        return f.get(target);
    }

    // ---------- Диалоговые окна ----------

    /** Окно, которое показало приложение во время действия */
    static final class Dialog {
        final String title;
        final String message;

        Dialog(String title, String message) {
            this.title = title;
            this.message = message;
        }

        @Override
        public String toString() {
            return title + ": " + message;
        }
    }

    /**
     * Выполняет действие в потоке событий Swing. Если приложение показывает
     * окно JOptionPane, оно запоминается и закрывается ответом answer
     * (JOptionPane.OK_OPTION / YES_OPTION / NO_OPTION).
     * Возвращает список всех показанных окон.
     */
    static List<Dialog> perform(Runnable action, int answer) throws Exception {
        List<Dialog> seen = Collections.synchronizedList(new ArrayList<Dialog>());
        Set<JDialog> handled = Collections.newSetFromMap(new IdentityHashMap<JDialog, Boolean>());
        AtomicBoolean stop = new AtomicBoolean(false);

        Thread watcher = new Thread(() -> {
            while (!stop.get()) {
                for (Window w : Window.getWindows()) {
                    if (w instanceof JDialog && w.isShowing()) {
                        JDialog d = (JDialog) w;
                        JOptionPane pane = find(d.getContentPane(), JOptionPane.class, x -> true);
                        if (pane == null && d.getContentPane() instanceof JOptionPane) {
                            pane = (JOptionPane) d.getContentPane();
                        }
                        if (pane != null && handled.add(d)) {
                            seen.add(new Dialog(d.getTitle(), String.valueOf(pane.getMessage())));
                            final JOptionPane p = pane;
                            SwingUtilities.invokeLater(() -> p.setValue(answer));
                        }
                    }
                }
                try {
                    Thread.sleep(15);
                } catch (InterruptedException e) {
                    return;
                }
            }
        }, "dialog-watcher");
        watcher.setDaemon(true);
        watcher.start();
        try {
            SwingUtilities.invokeAndWait(action);
        } finally {
            stop.set(true);
            watcher.join(2000);
        }
        return seen;
    }
}
