package shoppinglist;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Модульные тесты класса StorageHelper (сохранение и загрузка списка).
 * Настоящий файл products.dat на время тестов прячется и потом возвращается.
 */
@DisplayName("Тесты класса StorageHelper")
class StorageHelperTest {

    @BeforeEach
    void setUp() throws IOException {
        TestSupport.backupDataFile();
    }

    @AfterEach
    void tearDown() throws IOException {
        TestSupport.restoreDataFile();
    }

    @Test
    @DisplayName("Список, сохранённый в файл, загружается без изменений")
    void testSaveAndLoad() {
        Product milk = new Product("Молоко", 2);
        Product bread = new Product("Хлеб", 1);
        bread.setBought(true);
        List<Product> source = new ArrayList<>();
        source.add(milk);
        source.add(bread);

        StorageHelper.save(source);
        List<Product> loaded = StorageHelper.load();

        assertEquals(2, loaded.size());
        assertEquals("Молоко", loaded.get(0).getName());
        assertEquals(2, loaded.get(0).getQuantity());
        assertFalse(loaded.get(0).isBought());
        assertEquals("Хлеб", loaded.get(1).getName());
        assertEquals(1, loaded.get(1).getQuantity());
        assertTrue(loaded.get(1).isBought(), "Отметка «куплено» должна сохраниться");
    }

    @Test
    @DisplayName("Категория и цена сохраняются и загружаются")
    void testSaveAndLoadCategoryAndPrice() {
        List<Product> source = new ArrayList<>();
        source.add(new Product("Хлеб", 3, "Продукты", 45.5));

        StorageHelper.save(source);
        List<Product> loaded = StorageHelper.load();

        assertEquals(1, loaded.size());
        assertEquals("Продукты", loaded.get(0).getCategory());
        assertEquals(45.5, loaded.get(0).getPrice(), 0.0001);
    }

    @Test
    @DisplayName("Сохранение создаёт файл products.dat")
    void testSaveCreatesFile() {
        assertFalse(Files.exists(TestSupport.DATA_FILE));
        StorageHelper.save(new ArrayList<Product>());
        assertTrue(Files.exists(TestSupport.DATA_FILE));
    }

    @Test
    @DisplayName("Если файла нет, возвращается пустой список")
    void testLoadWithoutFile() {
        assertFalse(Files.exists(TestSupport.DATA_FILE));
        List<Product> loaded = StorageHelper.load();
        assertNotNull(loaded);
        assertTrue(loaded.isEmpty());
    }

    @Test
    @DisplayName("Пустой список сохраняется и загружается как пустой")
    void testSaveEmptyList() {
        StorageHelper.save(new ArrayList<Product>());
        List<Product> loaded = StorageHelper.load();
        assertNotNull(loaded);
        assertTrue(loaded.isEmpty());
    }

    @Test
    @DisplayName("Повторное сохранение заменяет старое содержимое")
    void testSaveOverwritesFile() {
        List<Product> list = new ArrayList<>();
        list.add(new Product("Молоко", 2));
        list.add(new Product("Хлеб", 1));
        StorageHelper.save(list);

        list.remove(0);
        StorageHelper.save(list);

        List<Product> loaded = StorageHelper.load();
        assertEquals(1, loaded.size());
        assertEquals("Хлеб", loaded.get(0).getName());
    }

    @Test
    @DisplayName("Повреждённый файл не приводит к ошибке, список пуст")
    void testLoadCorruptedFile() throws IOException {
        Files.write(TestSupport.DATA_FILE,
                "это не сериализованный объект".getBytes(StandardCharsets.UTF_8));

        List<Product> loaded = StorageHelper.load();
        assertNotNull(loaded);
        assertTrue(loaded.isEmpty());
    }

    @Test
    @DisplayName("Файл с объектом другого типа даёт пустой список")
    void testLoadWrongObjectType() throws IOException {
        try (ObjectOutputStream out = new ObjectOutputStream(
                new FileOutputStream(TestSupport.DATA_FILE.toFile()))) {
            out.writeObject("строка, а не список");
        }

        List<Product> loaded = StorageHelper.load();
        assertNotNull(loaded);
        assertTrue(loaded.isEmpty());
    }
}
