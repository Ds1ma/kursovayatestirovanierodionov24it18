package shoppinglist;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Попарное (pairwise) тестирование ввода товара — набор А из пункта 2.5.1.
 * Параметры и их допустимые значения:
 *   название  : «Молоко» | « Хлеб » (с пробелами по краям) | 50 символов
 *   количество: пусто | 5 | 9999
 *   цена      : пусто | 45,5 | 1000000
 *   категория : пусто | «Продукты» | 30 символов
 * Полный перебор — 3·3·3·3 = 81 комбинация, попарный набор — 9 комбинаций:
 * каждая пара значений любых двух параметров встречается хотя бы в одной из них.
 */
@DisplayName("Попарное тестирование ввода товара (набор А)")
class ProductServicePairwiseTest {

    private static final String NAME_50 = "а".repeat(50);
    private static final String CATEGORY_30 = "к".repeat(30);

    private void check(String name, String qty, String price, String category,
                       String expectedName, int expectedQty, double expectedPrice,
                       String expectedCategory) {
        Product p = ProductService.create(new ArrayList<Product>(), name, qty, price, category);
        assertEquals(expectedName, p.getName());
        assertEquals(expectedQty, p.getQuantity());
        assertEquals(expectedPrice, p.getPrice(), 0.0001);
        assertEquals(expectedCategory, p.getCategory());
        assertFalse(p.isBought());
    }

    @Test
    @DisplayName("ПС-1. «Молоко»; количество пусто; цена пусто; категория пусто")
    void ps1() {
        check("Молоко", "", "", "", "Молоко", 1, 0.0, Product.DEFAULT_CATEGORY);
    }

    @Test
    @DisplayName("ПС-2. «Молоко»; 5; 45,5; «Продукты»")
    void ps2() {
        check("Молоко", "5", "45,5", "Продукты", "Молоко", 5, 45.5, "Продукты");
    }

    @Test
    @DisplayName("ПС-3. «Молоко»; 9999; 1000000; категория из 30 символов")
    void ps3() {
        check("Молоко", "9999", "1000000", CATEGORY_30, "Молоко", 9999, 1_000_000.0, CATEGORY_30);
    }

    @Test
    @DisplayName("ПС-4. «  Хлеб  »; количество пусто; 45,5; категория из 30 символов")
    void ps4() {
        check("  Хлеб  ", "", "45,5", CATEGORY_30, "Хлеб", 1, 45.5, CATEGORY_30);
    }

    @Test
    @DisplayName("ПС-5. «  Хлеб  »; 5; 1000000; категория пусто")
    void ps5() {
        check("  Хлеб  ", "5", "1000000", "", "Хлеб", 5, 1_000_000.0, Product.DEFAULT_CATEGORY);
    }

    @Test
    @DisplayName("ПС-6. «  Хлеб  »; 9999; цена пусто; «Продукты»")
    void ps6() {
        check("  Хлеб  ", "9999", "", "Продукты", "Хлеб", 9999, 0.0, "Продукты");
    }

    @Test
    @DisplayName("ПС-7. Название из 50 символов; количество пусто; 1000000; «Продукты»")
    void ps7() {
        check(NAME_50, "", "1000000", "Продукты", NAME_50, 1, 1_000_000.0, "Продукты");
    }

    @Test
    @DisplayName("ПС-8. Название из 50 символов; 5; цена пусто; категория из 30 символов")
    void ps8() {
        check(NAME_50, "5", "", CATEGORY_30, NAME_50, 5, 0.0, CATEGORY_30);
    }

    @Test
    @DisplayName("ПС-9. Название из 50 символов; 9999; 45,5; категория пусто")
    void ps9() {
        check(NAME_50, "9999", "45,5", "", NAME_50, 9999, 45.5, Product.DEFAULT_CATEGORY);
    }
}
