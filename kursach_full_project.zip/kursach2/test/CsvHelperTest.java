package shoppinglist;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/** Модульные тесты экспорта и импорта списка в CSV (класс CsvHelper) */
@DisplayName("Тесты класса CsvHelper")
class CsvHelperTest {

    private File newTempFile() throws IOException {
        File file = Files.createTempFile("shopping-test", ".csv").toFile();
        file.deleteOnExit();
        return file;
    }

    private File fileWith(String content) throws IOException {
        File file = newTempFile();
        Files.write(file.toPath(), content.getBytes(StandardCharsets.UTF_8));
        return file;
    }

    private static void assertImportError(String expectedMessage, File file) {
        IllegalArgumentException e = assertThrows(IllegalArgumentException.class,
                () -> CsvHelper.importFrom(file));
        assertEquals(expectedMessage, e.getMessage());
    }

    @Test
    @DisplayName("Экспортированный список импортируется без потерь")
    void testRoundTrip() throws IOException {
        Product milk = new Product("Молоко", 2, "Молочные продукты", 60.5);
        Product bread = new Product("Хлеб", 1);
        bread.setBought(true);
        List<Product> source = new ArrayList<>();
        source.add(milk);
        source.add(bread);
        File file = newTempFile();

        CsvHelper.export(source, file);
        List<Product> loaded = CsvHelper.importFrom(file);

        assertEquals(2, loaded.size());
        assertEquals("Молоко", loaded.get(0).getName());
        assertEquals(2, loaded.get(0).getQuantity());
        assertEquals(60.5, loaded.get(0).getPrice(), 0.0001);
        assertEquals("Молочные продукты", loaded.get(0).getCategory());
        assertFalse(loaded.get(0).isBought());
        assertEquals("Хлеб", loaded.get(1).getName());
        assertEquals(Product.DEFAULT_CATEGORY, loaded.get(1).getCategory());
        assertTrue(loaded.get(1).isBought());
    }

    @Test
    @DisplayName("Файл начинается с заголовка и записан в UTF-8")
    void testFileContent() throws IOException {
        List<Product> source = new ArrayList<>();
        source.add(new Product("Молоко", 2, "Продукты", 60));
        File file = newTempFile();

        CsvHelper.export(source, file);
        String text = new String(Files.readAllBytes(file.toPath()), StandardCharsets.UTF_8);

        assertTrue(text.startsWith("\uFEFF" + CsvHelper.HEADER));
        assertTrue(text.contains("Молоко;2;60.00;Продукты;нет"));
    }

    @Test
    @DisplayName("Названия со знаками «;» и кавычками сохраняются правильно")
    void testSpecialCharacters() throws IOException {
        List<Product> source = new ArrayList<>();
        source.add(new Product("Сыр; \"Российский\"", 1, "Мол; прод", 100));
        File file = newTempFile();

        CsvHelper.export(source, file);
        List<Product> loaded = CsvHelper.importFrom(file);

        assertEquals(1, loaded.size());
        assertEquals("Сыр; \"Российский\"", loaded.get(0).getName());
        assertEquals("Мол; прод", loaded.get(0).getCategory());
    }

    @Test
    @DisplayName("Пустой список экспортируется и импортируется как пустой")
    void testEmptyList() throws IOException {
        File file = newTempFile();
        CsvHelper.export(new ArrayList<Product>(), file);
        assertTrue(CsvHelper.importFrom(file).isEmpty());
    }

    @Test
    @DisplayName("Файл без заголовка, с пустыми строками и запятой в цене читается")
    void testImportWithoutHeader() throws IOException {
        File file = fileWith("Хлеб;2;45,50;Продукты;да\r\n\r\nМолоко;1;;;нет\r\n");

        List<Product> loaded = CsvHelper.importFrom(file);

        assertEquals(2, loaded.size());
        assertEquals(45.5, loaded.get(0).getPrice(), 0.0001);
        assertTrue(loaded.get(0).isBought());
        assertEquals(0.0, loaded.get(1).getPrice(), 0.0001);
        assertEquals(Product.DEFAULT_CATEGORY, loaded.get(1).getCategory());
    }

    @Test
    @DisplayName("Ошибка в строке сообщается с номером строки")
    void testImportErrorLineNumber() throws IOException {
        File file = fileWith(CsvHelper.HEADER + "\n" + "Хлеб;abc;10;Продукты;нет\n");
        assertImportError("Строка 2: Количество должно быть целым числом!", file);
    }

    @Test
    @DisplayName("Неверное число полей в строке")
    void testImportWrongFieldCount() throws IOException {
        File file = fileWith("Хлеб;2;10\n");
        assertImportError("Строка 1: ожидается 5 полей, найдено 3", file);
    }

    @Test
    @DisplayName("В поле «Куплено» допустимы только «да» и «нет»")
    void testImportWrongBoughtValue() throws IOException {
        File file = fileWith("Хлеб;2;10;Продукты;возможно\n");
        assertImportError("Строка 1: в поле «Куплено» должно быть «да» или «нет»", file);
    }

    @Test
    @DisplayName("Не закрытые кавычки приводят к ошибке")
    void testImportUnclosedQuote() throws IOException {
        File file = fileWith("\"Хлеб;2;10;Продукты;нет\n");
        assertImportError("Строка 1: не закрыты кавычки", file);
    }

    @Test
    @DisplayName("Пустое название и неверная цена в файле отклоняются")
    void testImportInvalidValues() throws IOException {
        assertImportError("Строка 1: Название товара не может быть пустым!", fileWith(";1;10;Продукты;нет\n"));
        assertImportError("Строка 1: Цена должна быть числом!", fileWith("Хлеб;1;дорого;Продукты;нет\n"));
    }

    @Test
    @DisplayName("Разбор строки учитывает кавычки")
    void testSplit() {
        List<String> fields = CsvHelper.split("a;\"b;c\";\"d\"\"e\";");
        assertEquals(4, fields.size());
        assertEquals("a", fields.get(0));
        assertEquals("b;c", fields.get(1));
        assertEquals("d\"e", fields.get(2));
        assertEquals("", fields.get(3));
    }

    @Test
    @DisplayName("Несуществующий файл вызывает IOException")
    void testMissingFile() {
        File missing = new File("no-such-file-12345.csv");
        assertThrows(IOException.class, () -> CsvHelper.importFrom(missing));
    }
}
