package shoppinglist;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import static org.junit.jupiter.api.Assertions.*;

/** Модульные тесты класса Product (модель данных) */
@DisplayName("Тесты класса Product")
class ProductTest {

    private Product product;

    @BeforeEach
    void setUp() {
        product = new Product("Молоко", 2);
    }

    @Test
    @DisplayName("Создание товара устанавливает корректные поля")
    void testCreateProduct() {
        assertEquals("Молоко", product.getName());
        assertEquals(2, product.getQuantity());
        assertFalse(product.isBought(), "Новый товар не должен быть куплен");
    }

    @Test
    @DisplayName("Сеттер имени изменяет имя")
    void testSetName() {
        product.setName("Хлеб");
        assertEquals("Хлеб", product.getName());
    }

    @Test
    @DisplayName("Сеттер количества изменяет количество")
    void testSetQuantity() {
        product.setQuantity(5);
        assertEquals(5, product.getQuantity());
    }

    @Test
    @DisplayName("Переключение флага bought")
    void testSetBought() {
        product.setBought(true);
        assertTrue(product.isBought());
        product.setBought(false);
        assertFalse(product.isBought());
    }

    @Test
    @DisplayName("toString содержит имя, количество и отметку")
    void testToString() {
        String s = product.toString();
        assertTrue(s.contains("Молоко"));
        assertTrue(s.contains("2"));
        assertTrue(s.contains("[ ]"));

        product.setBought(true);
        assertTrue(product.toString().contains("[✓]"));
    }

    @Test
    @DisplayName("toString возвращает строку точного формата")
    void testToStringExactFormat() {
        assertEquals("[ ] Молоко  ×2", product.toString());
        product.setBought(true);
        assertEquals("[✓] Молоко  ×2", product.toString());
    }

    @Test
    @DisplayName("Изменение имени и количества отражается в toString")
    void testToStringAfterChanges() {
        product.setName("Хлеб");
        product.setQuantity(10);
        assertEquals("[ ] Хлеб  ×10", product.toString());
    }

    @Test
    @DisplayName("Новый товар без категории и цены получает значения по умолчанию")
    void testDefaultCategoryAndPrice() {
        assertEquals(Product.DEFAULT_CATEGORY, product.getCategory());
        assertEquals(0.0, product.getPrice(), 0.0001);
        assertEquals(0.0, product.getTotal(), 0.0001);
    }

    @Test
    @DisplayName("Конструктор с категорией и ценой задаёт все поля")
    void testCreateWithCategoryAndPrice() {
        Product bread = new Product("Хлеб", 3, "Продукты", 45.5);
        assertEquals("Хлеб", bread.getName());
        assertEquals(3, bread.getQuantity());
        assertEquals("Продукты", bread.getCategory());
        assertEquals(45.5, bread.getPrice(), 0.0001);
        assertFalse(bread.isBought());
    }

    @Test
    @DisplayName("Стоимость позиции равна цене, умноженной на количество")
    void testTotal() {
        Product bread = new Product("Хлеб", 3, "Продукты", 45.5);
        assertEquals(136.5, bread.getTotal(), 0.0001);
        bread.setQuantity(4);
        assertEquals(182.0, bread.getTotal(), 0.0001);
    }

    @Test
    @DisplayName("Пустая категория заменяется категорией по умолчанию")
    void testCategoryFallback() {
        product.setCategory(null);
        assertEquals(Product.DEFAULT_CATEGORY, product.getCategory());
        product.setCategory("");
        assertEquals(Product.DEFAULT_CATEGORY, product.getCategory());
        product.setCategory("Напитки");
        assertEquals("Напитки", product.getCategory());
    }

    @Test
    @DisplayName("Категория и цена не влияют на строку toString")
    void testToStringIgnoresCategoryAndPrice() {
        Product bread = new Product("Хлеб", 3, "Продукты", 45.5);
        assertEquals("[ ] Хлеб  ×3", bread.toString());
    }

    @Test
    @DisplayName("Сериализация сохраняет все поля товара")
    void testSerialization() throws Exception {
        product.setBought(true);

        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        try (ObjectOutputStream out = new ObjectOutputStream(bytes)) {
            out.writeObject(product);
        }
        Product copy;
        try (ObjectInputStream in = new ObjectInputStream(
                new ByteArrayInputStream(bytes.toByteArray()))) {
            copy = (Product) in.readObject();
        }

        assertEquals("Молоко", copy.getName());
        assertEquals(2, copy.getQuantity());
        assertTrue(copy.isBought());
    }

    @Test
    @DisplayName("Сериализация сохраняет категорию и цену")
    void testSerializationCategoryAndPrice() throws Exception {
        Product bread = new Product("Хлеб", 3, "Продукты", 45.5);

        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        try (ObjectOutputStream out = new ObjectOutputStream(bytes)) {
            out.writeObject(bread);
        }
        Product copy;
        try (ObjectInputStream in = new ObjectInputStream(
                new ByteArrayInputStream(bytes.toByteArray()))) {
            copy = (Product) in.readObject();
        }

        assertEquals("Продукты", copy.getCategory());
        assertEquals(45.5, copy.getPrice(), 0.0001);
    }
}
