package shoppinglist;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/** Модульные тесты поиска, фильтрации и сортировки (класс ProductFilter) */
@DisplayName("Тесты класса ProductFilter")
class ProductFilterTest {

    private Product milk;
    private Product bread;
    private Product soap;
    private Product apples;
    private List<Product> all;

    @BeforeEach
    void setUp() {
        milk = new Product("Молоко", 2, "Продукты", 60);
        bread = new Product("Хлеб", 1, "Продукты", 40);
        soap = new Product("Мыло", 1, "Бытовая химия", 80);
        soap.setBought(true);
        apples = new Product("Яблоки", 3, "Овощи и фрукты", 120);
        all = new ArrayList<>();
        all.add(milk);
        all.add(bread);
        all.add(soap);
        all.add(apples);
    }

    private List<Product> apply(String query, String category, boolean hideBought,
                                ProductFilter.SortMode mode) {
        return ProductFilter.apply(all, query, category, hideBought, mode);
    }

    @Test
    @DisplayName("Без условий возвращаются все товары в порядке добавления")
    void testNoFilters() {
        List<Product> result = apply("", ProductFilter.ALL_CATEGORIES, false, ProductFilter.SortMode.ADDED);
        assertEquals(List.of(milk, bread, soap, apples), result);
    }

    @Test
    @DisplayName("Поиск по части названия без учёта регистра")
    void testSearch() {
        assertEquals(List.of(milk), apply("мол", ProductFilter.ALL_CATEGORIES, false, ProductFilter.SortMode.ADDED));
        assertEquals(List.of(milk), apply("МОЛ", ProductFilter.ALL_CATEGORIES, false, ProductFilter.SortMode.ADDED));
        assertEquals(List.of(milk, soap), apply("м", ProductFilter.ALL_CATEGORIES, false, ProductFilter.SortMode.ADDED));
        assertTrue(apply("ничего", ProductFilter.ALL_CATEGORIES, false, ProductFilter.SortMode.ADDED).isEmpty());
    }

    @Test
    @DisplayName("Пробелы вокруг строки поиска игнорируются")
    void testSearchTrimmed() {
        assertEquals(List.of(milk), apply("  мол  ", ProductFilter.ALL_CATEGORIES, false, ProductFilter.SortMode.ADDED));
    }

    @Test
    @DisplayName("Фильтр по категории")
    void testCategoryFilter() {
        assertEquals(List.of(milk, bread), apply("", "Продукты", false, ProductFilter.SortMode.ADDED));
        assertEquals(List.of(soap), apply("", "бытовая химия", false, ProductFilter.SortMode.ADDED));
        assertTrue(apply("", "Одежда", false, ProductFilter.SortMode.ADDED).isEmpty());
    }

    @Test
    @DisplayName("Скрытие купленных товаров")
    void testHideBought() {
        assertEquals(List.of(milk, bread, apples), apply("", null, true, ProductFilter.SortMode.ADDED));
    }

    @Test
    @DisplayName("Поиск, категория и скрытие купленных работают вместе")
    void testCombined() {
        assertEquals(List.of(bread), apply("х", "Продукты", true, ProductFilter.SortMode.ADDED));
        assertTrue(apply("мыло", ProductFilter.ALL_CATEGORIES, true, ProductFilter.SortMode.ADDED).isEmpty());
    }

    @Test
    @DisplayName("Сортировка по названию")
    void testSortByName() {
        assertEquals(List.of(milk, soap, bread, apples),
                apply("", null, false, ProductFilter.SortMode.NAME));
    }

    @Test
    @DisplayName("Сортировка по категории, внутри категории по названию")
    void testSortByCategory() {
        assertEquals(List.of(soap, apples, milk, bread),
                apply("", null, false, ProductFilter.SortMode.CATEGORY));
    }

    @Test
    @DisplayName("Сортировка: сначала некупленные, порядок внутри групп сохраняется")
    void testSortUnboughtFirst() {
        assertEquals(List.of(milk, bread, apples, soap),
                apply("", null, false, ProductFilter.SortMode.UNBOUGHT_FIRST));
    }

    @Test
    @DisplayName("Сортировка по цене: сначала дорогие")
    void testSortByPrice() {
        assertEquals(List.of(apples, soap, milk, bread),
                apply("", null, false, ProductFilter.SortMode.PRICE_DESC));
    }

    @Test
    @DisplayName("Исходный список не изменяется")
    void testSourceNotChanged() {
        apply("", null, true, ProductFilter.SortMode.NAME);
        assertEquals(List.of(milk, bread, soap, apples), all);
    }

    @Test
    @DisplayName("Названия способов сортировки читаемы")
    void testSortModeLabels() {
        assertEquals("По названию", ProductFilter.SortMode.NAME.toString());
        assertEquals("По добавлению", ProductFilter.SortMode.ADDED.toString());
    }
}
