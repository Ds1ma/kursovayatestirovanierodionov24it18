package shoppinglist;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/** Модульные тесты подсчёта статистики (класс ShoppingStats) */
@DisplayName("Тесты класса ShoppingStats")
class ShoppingStatsTest {

    private List<Product> products;

    @BeforeEach
    void setUp() {
        Product milk = new Product("Молоко", 2, "Продукты", 60);      // 120
        Product bread = new Product("Хлеб", 1, "Продукты", 40);       // 40
        Product soap = new Product("Мыло", 1, "Бытовая химия", 80);   // 80
        Product apples = new Product("Яблоки", 3, "Овощи и фрукты", 120);   // 360
        soap.setBought(true);
        apples.setBought(true);
        products = new ArrayList<>();
        products.add(milk);
        products.add(bread);
        products.add(soap);
        products.add(apples);
    }

    @Test
    @DisplayName("Подсчёт количества товаров")
    void testCounts() {
        ShoppingStats stats = new ShoppingStats(products);
        assertEquals(4, stats.getTotalCount());
        assertEquals(2, stats.getBoughtCount());
        assertEquals(2, stats.getRemainingCount());
    }

    @Test
    @DisplayName("Подсчёт стоимости: весь список, купленное и остаток")
    void testCosts() {
        ShoppingStats stats = new ShoppingStats(products);
        assertEquals(600.0, stats.getTotalCost(), 0.0001);
        assertEquals(440.0, stats.getBoughtCost(), 0.0001);
        assertEquals(160.0, stats.getRemainingCost(), 0.0001);
    }

    @Test
    @DisplayName("Подсчёт по категориям")
    void testByCategory() {
        ShoppingStats stats = new ShoppingStats(products);
        assertEquals(2, stats.getCountByCategory().get("Продукты"));
        assertEquals(160.0, stats.getCostByCategory().get("Продукты"), 0.0001);
        assertEquals(1, stats.getCountByCategory().get("Бытовая химия"));
        assertEquals(3, stats.getCountByCategory().size());
    }

    @Test
    @DisplayName("Товары без цены учитываются в количестве, но не в сумме")
    void testProductsWithoutPrice() {
        List<Product> list = new ArrayList<>();
        list.add(new Product("Соль", 1));
        ShoppingStats stats = new ShoppingStats(list);
        assertEquals(1, stats.getTotalCount());
        assertEquals(0.0, stats.getTotalCost(), 0.0001);
    }

    @Test
    @DisplayName("Пустой список даёт нулевые значения")
    void testEmptyList() {
        ShoppingStats stats = new ShoppingStats(new ArrayList<Product>());
        assertEquals(0, stats.getTotalCount());
        assertEquals(0.0, stats.getTotalCost(), 0.0001);
        assertTrue(stats.report().contains("Всего товаров: 0"));
    }

    @Test
    @DisplayName("Краткая строка и денежный формат")
    void testSummaryAndMoney() {
        assertEquals("120.50 ₽", ShoppingStats.money(120.5));
        assertEquals("0.00 ₽", ShoppingStats.money(0));
        assertEquals("Товаров: 4 | Куплено: 2 | Сумма: 600.00 ₽ | Осталось купить: 160.00 ₽",
                new ShoppingStats(products).summary());
    }

    @Test
    @DisplayName("Отчёт содержит итоги и категории")
    void testReport() {
        String report = new ShoppingStats(products).report();
        assertTrue(report.contains("Всего товаров: 4"));
        assertTrue(report.contains("Стоимость списка: 600.00 ₽"));
        assertTrue(report.contains("Продукты: 2 шт., 160.00 ₽"));
        assertTrue(report.contains("Бытовая химия"));
    }
}
