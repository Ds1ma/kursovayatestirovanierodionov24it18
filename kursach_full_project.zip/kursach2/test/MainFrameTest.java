package shoppinglist;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Timeout;

import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assumptions.assumeFalse;

/**
 * Автоматизированные тестовые сценарии ТС-1 ... ТС-14 из пункта 2.5.1:
 * функциональное тестирование и обработка исключительных ситуаций.
 * Тесты запускают настоящее окно MainFrame, нажимают его кнопки и читают
 * сообщения, которые показывает приложение. Всплывающие окна (ошибки,
 * подтверждение) закрываются автоматически.
 *
 * Для работы нужен экран (не headless-режим). Настоящий products.dat
 * на время тестов прячется и затем возвращается на место.
 */
@Timeout(60)
@DisplayName("Тесты главного окна MainFrame")
class MainFrameTest {

    private static final String ERROR_TITLE = "Ошибка ввода";

    private MainFrame frame;
    private DefaultListModel<Product> model;
    private List<Product> products;
    private JList<Product> list;
    private JTextField nameField;
    private JTextField qtyField;
    private JLabel status;
    private JTextField priceField;
    private JComboBox<String> categoryBox;
    private JTextField searchField;
    private JComboBox<String> filterBox;
    private JCheckBox hideBoughtBox;
    private JComboBox<ProductFilter.SortMode> sortBox;
    private JLabel summaryLabel;
    private boolean dataBackedUp;

    @BeforeEach
    void setUp() throws Exception {
        assumeFalse(GraphicsEnvironment.isHeadless(),
                "Нужен графический экран, тест пропущен");
        TestSupport.backupDataFile();
        dataBackedUp = true;
        openFrame();
    }

    @AfterEach
    void tearDown() throws Exception {
        closeFrame();
        if (dataBackedUp) {
            TestSupport.restoreDataFile();
            dataBackedUp = false;
        }
    }

    // ================= Вспомогательные методы =================

    @SuppressWarnings("unchecked")
    private void openFrame() throws Exception {
        SwingUtilities.invokeAndWait(() -> frame = new MainFrame());
        model = (DefaultListModel<Product>) TestSupport.field(frame, "listModel");
        products = (List<Product>) TestSupport.field(frame, "products");
        list = (JList<Product>) TestSupport.field(frame, "productList");
        nameField = (JTextField) TestSupport.field(frame, "nameField");
        qtyField = (JTextField) TestSupport.field(frame, "qtyField");
        status = (JLabel) TestSupport.field(frame, "statusLabel");
        priceField = (JTextField) TestSupport.field(frame, "priceField");
        categoryBox = (JComboBox<String>) TestSupport.field(frame, "categoryBox");
        searchField = (JTextField) TestSupport.field(frame, "searchField");
        filterBox = (JComboBox<String>) TestSupport.field(frame, "filterBox");
        hideBoughtBox = (JCheckBox) TestSupport.field(frame, "hideBoughtBox");
        sortBox = (JComboBox<ProductFilter.SortMode>) TestSupport.field(frame, "sortBox");
        summaryLabel = (JLabel) TestSupport.field(frame, "summaryLabel");
    }

    private void closeFrame() throws Exception {
        if (frame != null) {
            SwingUtilities.invokeAndWait(() -> frame.dispose());
            frame = null;
        }
    }

    /** Вводит название и количество и нажимает «Добавить» */
    private List<TestSupport.Dialog> add(String name, String qty) throws Exception {
        return TestSupport.perform(() -> {
            nameField.setText(name);
            qtyField.setText(qty);
            TestSupport.button(frame, "Добавить").doClick(0);
        }, JOptionPane.OK_OPTION);
    }

    /** Вводит название, количество, цену и категорию и нажимает «Добавить» */
    private List<TestSupport.Dialog> addFull(String name, String qty, String price,
                                             String category) throws Exception {
        return TestSupport.perform(() -> {
            nameField.setText(name);
            qtyField.setText(qty);
            priceField.setText(price);
            categoryBox.getEditor().setItem(category);
            TestSupport.button(frame, "Добавить").doClick(0);
        }, JOptionPane.OK_OPTION);
    }

    private void edt(Runnable action) throws Exception {
        SwingUtilities.invokeAndWait(action);
    }

    private String nameAt(int index) {
        return model.get(index).getName();
    }

    /** Нажимает кнопку с указанным текстом; answer — ответ на окно подтверждения */
    private List<TestSupport.Dialog> press(String buttonText, int answer) throws Exception {
        return TestSupport.perform(() -> TestSupport.button(frame, buttonText).doClick(0), answer);
    }

    private List<TestSupport.Dialog> press(String buttonText) throws Exception {
        return press(buttonText, JOptionPane.OK_OPTION);
    }

    private void select(int index) throws Exception {
        SwingUtilities.invokeAndWait(() -> list.setSelectedIndex(index));
    }

    private void assertNoDialogs(List<TestSupport.Dialog> dialogs) {
        assertTrue(dialogs.isEmpty(), "Не должно быть всплывающих окон, но было: " + dialogs);
    }

    private void assertError(List<TestSupport.Dialog> dialogs, String expectedMessage) {
        assertEquals(1, dialogs.size(), "Должно быть одно окно ошибки, но было: " + dialogs);
        assertEquals(ERROR_TITLE, dialogs.get(0).title);
        assertEquals(expectedMessage, dialogs.get(0).message);
    }

    // ================= Функциональное тестирование (сценарии ТС-1 ... ТС-8) =================

    @Test
    @DisplayName("ТС-1а. Добавление товара с названием и количеством")
    void tc01a_addProduct() throws Exception {
        List<TestSupport.Dialog> dialogs = add("Молоко", "2");

        assertNoDialogs(dialogs);
        assertEquals(1, model.size());
        assertEquals(1, products.size());
        assertEquals("Молоко", model.get(0).getName());
        assertEquals(2, model.get(0).getQuantity());
        assertFalse(model.get(0).isBought());
        assertEquals("", nameField.getText(), "Поле названия должно очиститься");
        assertEquals("", qtyField.getText(), "Поле количества должно очиститься");
        assertTrue(status.getText().startsWith("Добавлено:"), status.getText());
        assertTrue(status.getText().contains("Молоко"), status.getText());
    }

    @Test
    @DisplayName("ТС-1б. Добавление без количества, количество = 1")
    void tc01b_addWithoutQuantity() throws Exception {
        List<TestSupport.Dialog> dialogs = add("Сыр", "");

        assertNoDialogs(dialogs);
        assertEquals(1, model.size());
        assertEquals(1, model.get(0).getQuantity());
    }

    @Test
    @DisplayName("ТС-1в. Добавление товара с ценой и категорией, итоговая сумма")
    void tc01c_addWithPriceAndCategory() throws Exception {
        List<TestSupport.Dialog> dialogs = addFull("Молоко", "2", "60,5", "Молочные продукты");

        assertNoDialogs(dialogs);
        assertEquals(1, model.size());
        assertEquals(60.5, model.get(0).getPrice(), 0.0001);
        assertEquals("Молочные продукты", model.get(0).getCategory());
        assertEquals("", priceField.getText(), "Поле цены должно очиститься");
        assertEquals("Товаров: 1 | Куплено: 0 | Сумма: 121.00 ₽ | Осталось купить: 121.00 ₽",
                summaryLabel.getText());
    }

    @Test
    @DisplayName("ТС-2а. Отметка товара купленным кнопкой")
    void tc02a_markBought() throws Exception {
        add("Молоко", "2");
        select(0);

        List<TestSupport.Dialog> dialogs = press("Отметить купленным");

        assertNoDialogs(dialogs);
        assertTrue(model.get(0).isBought());
        assertTrue(model.get(0).toString().contains("[✓]"));
        assertEquals("Отмечено купленным: Молоко", status.getText());
        assertEquals(0, list.getSelectedIndex(), "Выделение должно сохраниться");
    }

    @Test
    @DisplayName("ТС-2б. Снятие отметки повторным нажатием")
    void tc02b_unmarkBought() throws Exception {
        add("Молоко", "2");
        select(0);
        press("Отметить купленным");

        List<TestSupport.Dialog> dialogs = press("Отметить купленным");

        assertNoDialogs(dialogs);
        assertFalse(model.get(0).isBought());
        assertTrue(model.get(0).toString().contains("[ ]"));
        assertEquals("Снята отметка: Молоко", status.getText());
    }

    @Test
    @DisplayName("ТС-3. Удаление выделенного товара")
    void tc03_deleteProduct() throws Exception {
        add("Молоко", "2");
        add("Хлеб", "1");
        select(0);

        List<TestSupport.Dialog> dialogs = press("Удалить");

        assertNoDialogs(dialogs);
        assertEquals(1, model.size());
        assertEquals(1, products.size());
        assertEquals("Хлеб", model.get(0).getName());
        assertEquals("Удалено: Молоко", status.getText());
    }

    @Test
    @DisplayName("ТС-4а. Очистка списка: ответ «Нет» оставляет список без изменений")
    void tc04a_clearAllCancelled() throws Exception {
        add("Молоко", "2");
        add("Хлеб", "1");

        List<TestSupport.Dialog> dialogs = press("Очистить всё", JOptionPane.NO_OPTION);

        assertEquals(1, dialogs.size());
        assertEquals("Подтверждение", dialogs.get(0).title);
        assertTrue(dialogs.get(0).message.contains("2"),
                "В запросе должно быть количество товаров: " + dialogs.get(0).message);
        assertEquals(2, model.size());
        assertEquals(2, products.size());
    }

    @Test
    @DisplayName("ТС-4б. Очистка списка: ответ «Да» удаляет все товары")
    void tc04b_clearAllConfirmed() throws Exception {
        add("Молоко", "2");
        add("Хлеб", "1");

        List<TestSupport.Dialog> dialogs = press("Очистить всё", JOptionPane.YES_OPTION);

        assertEquals(1, dialogs.size());
        assertEquals("Подтверждение", dialogs.get(0).title);
        assertEquals(0, model.size());
        assertEquals(0, products.size());
        assertEquals("Список очищен.", status.getText());
    }

    @Test
    @DisplayName("ТС-5а. Поиск по части названия")
    void tc05a_search() throws Exception {
        add("Молоко", "1");
        add("Хлеб", "1");

        edt(() -> searchField.setText("мол"));
        assertEquals(1, model.size());
        assertEquals("Молоко", nameAt(0));
        assertEquals(2, products.size(), "Поиск не должен удалять товары");

        edt(() -> searchField.setText(""));
        assertEquals(2, model.size());
    }

    @Test
    @DisplayName("ТС-5б. Фильтр по категории")
    void tc05b_categoryFilter() throws Exception {
        addFull("Молоко", "1", "", "Продукты");
        addFull("Мыло", "1", "", "Бытовая химия");

        edt(() -> filterBox.setSelectedItem("Бытовая химия"));
        assertEquals(1, model.size());
        assertEquals("Мыло", nameAt(0));

        edt(() -> filterBox.setSelectedItem(ProductFilter.ALL_CATEGORIES));
        assertEquals(2, model.size());
    }

    @Test
    @DisplayName("ТС-5в. Скрытие купленных товаров")
    void tc05c_hideBought() throws Exception {
        add("Молоко", "1");
        add("Хлеб", "1");
        select(0);
        press("Отметить купленным");

        edt(() -> hideBoughtBox.doClick(0));
        assertEquals(1, model.size());
        assertEquals("Хлеб", nameAt(0));

        edt(() -> hideBoughtBox.doClick(0));
        assertEquals(2, model.size());
    }

    @Test
    @DisplayName("ТС-5г. Сортировка по названию и по цене")
    void tc05d_sort() throws Exception {
        addFull("Яблоки", "1", "120", "");
        addFull("Хлеб", "1", "40", "");
        addFull("Молоко", "1", "60", "");

        edt(() -> sortBox.setSelectedItem(ProductFilter.SortMode.NAME));
        assertEquals("Молоко", nameAt(0));
        assertEquals("Хлеб", nameAt(1));
        assertEquals("Яблоки", nameAt(2));

        edt(() -> sortBox.setSelectedItem(ProductFilter.SortMode.PRICE_DESC));
        assertEquals("Яблоки", nameAt(0));
        assertEquals("Молоко", nameAt(1));
        assertEquals("Хлеб", nameAt(2));

        edt(() -> sortBox.setSelectedItem(ProductFilter.SortMode.ADDED));
        assertEquals("Яблоки", nameAt(0));
    }

    @Test
    @DisplayName("ТС-6а. Итоговая сумма меняется после отметки товара")
    void tc06a_summaryAfterToggle() throws Exception {
        addFull("Молоко", "2", "60", "");
        select(0);

        press("Отметить купленным");

        assertEquals("Товаров: 1 | Куплено: 1 | Сумма: 120.00 ₽ | Осталось купить: 0.00 ₽",
                summaryLabel.getText());
    }

    @Test
    @DisplayName("ТС-6б. Окно статистики")
    void tc06b_statistics() throws Exception {
        addFull("Молоко", "2", "60", "Продукты");

        List<TestSupport.Dialog> dialogs = press("Статистика");

        assertEquals(1, dialogs.size());
        assertEquals("Статистика", dialogs.get(0).title);
        assertTrue(dialogs.get(0).message.contains("Всего товаров: 1"), dialogs.get(0).message);
        assertTrue(dialogs.get(0).message.contains("Стоимость списка: 120.00 ₽"), dialogs.get(0).message);
    }

    @Test
    @DisplayName("ТС-7а. После перезапуска список восстанавливается из файла")
    void tc07a_dataPersistsBetweenRuns() throws Exception {
        add("Молоко", "2");
        add("Хлеб", "1");
        select(0);
        press("Отметить купленным");

        closeFrame();
        openFrame();

        assertEquals(2, model.size());
        assertEquals("Молоко", model.get(0).getName());
        assertEquals(2, model.get(0).getQuantity());
        assertTrue(model.get(0).isBought(), "Отметка должна сохраниться");
        assertEquals("Хлеб", model.get(1).getName());
        assertFalse(model.get(1).isBought());
        assertEquals("Куплено: 1 из 2", status.getText());
    }

    @Test
    @DisplayName("ТС-7б. Категория и цена сохраняются между запусками")
    void tc07b_categoryAndPricePersist() throws Exception {
        addFull("Молоко", "2", "60,5", "Молочные продукты");

        closeFrame();
        openFrame();

        assertEquals(1, model.size());
        assertEquals("Молочные продукты", model.get(0).getCategory());
        assertEquals(60.5, model.get(0).getPrice(), 0.0001);
        assertEquals("Товаров: 1 | Куплено: 0 | Сумма: 121.00 ₽ | Осталось купить: 121.00 ₽",
                summaryLabel.getText());
    }

    @Test
    @DisplayName("ТС-7в. Кнопка «Сохранить» записывает список в products.dat")
    void tc07c_saveButton() throws Exception {
        add("Молоко", "2");
        Files.deleteIfExists(TestSupport.DATA_FILE);

        List<TestSupport.Dialog> dialogs = press("Сохранить");

        assertNoDialogs(dialogs);
        assertTrue(Files.exists(TestSupport.DATA_FILE), "Файл products.dat должен появиться");
        assertEquals("Список сохранён в файл products.dat", status.getText());
        assertEquals(1, StorageHelper.load().size());
    }

    @Test
    @DisplayName("ТС-8. Экспорт в файл и импорт обратно; повторный импорт пропускает дубликаты")
    void tc08_exportAndImport() throws Exception {
        addFull("Молоко", "2", "60", "Продукты");
        addFull("Хлеб", "1", "40", "Продукты");
        File file = File.createTempFile("shopping-ui", ".csv");
        file.deleteOnExit();

        assertNoDialogs(TestSupport.perform(() -> frame.exportFile(file), JOptionPane.OK_OPTION));
        assertTrue(status.getText().startsWith("Экспортировано товаров: 2"), status.getText());

        press("Очистить всё", JOptionPane.YES_OPTION);
        assertEquals(0, model.size());

        assertNoDialogs(TestSupport.perform(() -> frame.importFile(file), JOptionPane.OK_OPTION));
        assertEquals(2, model.size());
        assertEquals("Молоко", nameAt(0));
        assertEquals(2, model.get(0).getQuantity());
        assertEquals(60.0, model.get(0).getPrice(), 0.0001);
        assertEquals("Импортировано товаров: 2, пропущено дубликатов: 0", status.getText());

        TestSupport.perform(() -> frame.importFile(file), JOptionPane.OK_OPTION);
        assertEquals(2, model.size());
        assertEquals("Импортировано товаров: 0, пропущено дубликатов: 2", status.getText());
    }

    // ================= Обработка исключительных ситуаций (сценарии ТС-9 ... ТС-14) =================

    @Test
    @DisplayName("ТС-9а. Пустое название")
    void tc09a_emptyName() throws Exception {
        assertError(add("", "1"), "Название товара не может быть пустым!");
        assertEquals(0, model.size());
    }

    @Test
    @DisplayName("ТС-9б. Название из одних пробелов считается пустым")
    void tc09b_blankName() throws Exception {
        assertError(add("   ", "1"), "Название товара не может быть пустым!");
        assertEquals(0, model.size());
    }

    @Test
    @DisplayName("ТС-9в. Название длиной 51 символ")
    void tc09c_nameTooLong() throws Exception {
        String name51 = "а" + "б".repeat(50);
        assertEquals(51, name51.length());

        assertError(add(name51, "1"), "Название слишком длинное (макс. 50 символов).");
        assertEquals(0, model.size());
    }

    @Test
    @DisplayName("ТС-9г. Граничное значение: название длиной 50 символов допустимо")
    void tc09d_nameMaxLength() throws Exception {
        String name50 = "б".repeat(50);

        assertNoDialogs(add(name50, "1"));
        assertEquals(1, model.size());
    }

    @Test
    @DisplayName("ТС-10а. Нечисловое количество")
    void tc10a_quantityNotNumber() throws Exception {
        assertError(add("Хлеб", "abc"), "Количество должно быть целым числом!");
        assertEquals(0, model.size());
    }

    @Test
    @DisplayName("ТС-10б. Дробное количество")
    void tc10b_quantityFraction() throws Exception {
        assertError(add("Хлеб", "2.5"), "Количество должно быть целым числом!");
        assertEquals(0, model.size());
    }

    @Test
    @DisplayName("ТС-10в. Слишком длинное число не помещается в int")
    void tc10c_quantityOverflow() throws Exception {
        assertError(add("Хлеб", "99999999999"), "Количество должно быть целым числом!");
        assertEquals(0, model.size());
    }

    @Test
    @DisplayName("ТС-10г. Нулевое количество")
    void tc10d_quantityZero() throws Exception {
        assertError(add("Хлеб", "0"), "Количество должно быть больше нуля!");
        assertEquals(0, model.size());
    }

    @Test
    @DisplayName("ТС-10д. Отрицательное количество")
    void tc10e_quantityNegative() throws Exception {
        assertError(add("Хлеб", "-3"), "Количество должно быть больше нуля!");
        assertEquals(0, model.size());
    }

    @Test
    @DisplayName("ТС-10е. Количество 10000 больше допустимого")
    void tc10f_quantityTooBig() throws Exception {
        assertError(add("Хлеб", "10000"), "Слишком большое количество (макс. 9999).");
        assertEquals(0, model.size());
    }

    @Test
    @DisplayName("ТС-10ж. Граничные значения количества 1 и 9999 допустимы")
    void tc10g_quantityBoundaries() throws Exception {
        assertNoDialogs(add("Хлеб", "1"));
        assertNoDialogs(add("Сыр", "9999"));

        assertEquals(2, model.size());
        assertEquals(1, model.get(0).getQuantity());
        assertEquals(9999, model.get(1).getQuantity());
    }

    @Test
    @DisplayName("ТС-11а. Неверная цена: не число, отрицательная, слишком большая")
    void tc11a_invalidPrice() throws Exception {
        assertError(addFull("Хлеб", "1", "abc", ""), "Цена должна быть числом!");
        assertError(addFull("Хлеб", "1", "-5", ""), "Цена не может быть отрицательной!");
        assertError(addFull("Хлеб", "1", "1000001", ""), "Слишком большая цена (макс. 1000000).");
        assertEquals(0, model.size());
    }

    @Test
    @DisplayName("ТС-11б. Слишком длинное название категории")
    void tc11b_categoryTooLong() throws Exception {
        assertError(addFull("Хлеб", "1", "", "к".repeat(31)),
                "Название категории слишком длинное (макс. 30 символов).");
        assertEquals(0, model.size());
    }

    @Test
    @DisplayName("ТС-12а. Дубликат названия без учёта регистра")
    void tc12a_duplicateName() throws Exception {
        add("Молоко", "2");

        assertError(add("молоко", "1"), "Товар \"молоко\" уже есть в списке!");
        assertEquals(1, model.size());
        assertEquals(2, model.get(0).getQuantity(), "Исходный товар не должен измениться");
    }

    @Test
    @DisplayName("ТС-12б. Дубликат того же названия и того же регистра")
    void tc12b_duplicateSameCase() throws Exception {
        add("Молоко", "2");

        assertError(add("Молоко", "2"), "Товар \"Молоко\" уже есть в списке!");
        assertEquals(1, model.size());
    }

    @Test
    @DisplayName("ТС-13а. Отметка без выделенного товара")
    void tc13a_toggleWithoutSelection() throws Exception {
        add("Молоко", "2");

        assertError(press("Отметить купленным"), "Сначала выберите товар в списке!");
        assertFalse(model.get(0).isBought());
    }

    @Test
    @DisplayName("ТС-13б. Удаление без выделенного товара")
    void tc13b_deleteWithoutSelection() throws Exception {
        add("Молоко", "2");

        assertError(press("Удалить"), "Сначала выберите товар для удаления!");
        assertEquals(1, model.size());
    }

    @Test
    @DisplayName("ТС-13в. Редактирование без выделенного товара")
    void tc13c_editWithoutSelection() throws Exception {
        add("Молоко", "2");

        assertError(press("Редактировать"), "Сначала выберите товар для редактирования!");
    }

    @Test
    @DisplayName("ТС-13г. Очистка пустого списка")
    void tc13d_clearEmptyList() throws Exception {
        assertError(press("Очистить всё"), "Список уже пуст!");
    }

    @Test
    @DisplayName("ТС-14. Импорт повреждённого файла: сообщение об ошибке, список не меняется")
    void tc14_importBrokenFile() throws Exception {
        add("Молоко", "1");
        File file = File.createTempFile("shopping-broken", ".csv");
        file.deleteOnExit();
        Files.write(file.toPath(), "мусор".getBytes(StandardCharsets.UTF_8));

        List<TestSupport.Dialog> dialogs = TestSupport.perform(() -> frame.importFile(file),
                JOptionPane.OK_OPTION);

        assertError(dialogs, "Ошибка в файле. Строка 1: ожидается 5 полей, найдено 1");
        assertEquals(1, model.size());
    }
}
