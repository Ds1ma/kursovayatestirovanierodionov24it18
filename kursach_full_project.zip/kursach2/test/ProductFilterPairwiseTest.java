package shoppinglist;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Попарное (pairwise) тестирование настроек просмотра списка — набор Б из пункта 2.5.1.
 * Параметры и их значения:
 *   поиск           : пусто | «мол» | «о»
 *   категория       : «Все категории» | «Продукты» | «Бытовая химия»
 *   скрыть купленные: нет | да
 *   сортировка      : по добавлению | по названию | сначала дорогие
 * Полный перебор — 3·3·2·3 = 54 комбинации, попарный набор — 9 комбинаций.
 *
 * Список для всех тестов (в порядке добавления):
 *   Молоко (Продукты, 60 ₽), Хлеб (Продукты, 40 ₽, куплен), Мыло (Бытовая химия, 80 ₽),
 *   Яблоки (Овощи и фрукты, 120 ₽, куплены), Молочный шоколад (Продукты, 150 ₽).
 */
@DisplayName("Попарное тестирование просмотра списка (набор Б)")
class ProductFilterPairwiseTest {

    private static final String ALL = ProductFilter.ALL_CATEGORIES;
    private List<Product> products;

    @BeforeEach
    void setUp() {
        Product bread = new Product("Хлеб", 1, "Продукты", 40);
        bread.setBought(true);
        Product apples = new Product("Яблоки", 3, "Овощи и фрукты", 120);
        apples.setBought(true);

        products = new ArrayList<>();
        products.add(new Product("Молоко", 2, "Продукты", 60));
        products.add(bread);
        products.add(new Product("Мыло", 1, "Бытовая химия", 80));
        products.add(apples);
        products.add(new Product("Молочный шоколад", 1, "Продукты", 150));
    }

    private void check(String query, String category, boolean hideBought,
                       ProductFilter.SortMode mode, String... expectedNames) {
        List<String> names = new ArrayList<>();
        for (Product p : ProductFilter.apply(products, query, category, hideBought, mode)) {
            names.add(p.getName());
        }
        assertEquals(Arrays.asList(expectedNames), names);
    }

    @Test
    @DisplayName("ПВ-1. Поиск пусто; все категории; не скрывать; по добавлению")
    void pv1() {
        check("", ALL, false, ProductFilter.SortMode.ADDED,
                "Молоко", "Хлеб", "Мыло", "Яблоки", "Молочный шоколад");
    }

    @Test
    @DisplayName("ПВ-2. Поиск пусто; «Продукты»; скрыть купленные; по названию")
    void pv2() {
        check("", "Продукты", true, ProductFilter.SortMode.NAME,
                "Молоко", "Молочный шоколад");
    }

    @Test
    @DisplayName("ПВ-3. Поиск пусто; «Бытовая химия»; не скрывать; сначала дорогие")
    void pv3() {
        check("", "Бытовая химия", false, ProductFilter.SortMode.PRICE_DESC, "Мыло");
    }

    @Test
    @DisplayName("ПВ-4. Поиск «мол»; все категории; скрыть купленные; сначала дорогие")
    void pv4() {
        check("мол", ALL, true, ProductFilter.SortMode.PRICE_DESC,
                "Молочный шоколад", "Молоко");
    }

    @Test
    @DisplayName("ПВ-5. Поиск «мол»; «Продукты»; не скрывать; по добавлению")
    void pv5() {
        check("мол", "Продукты", false, ProductFilter.SortMode.ADDED,
                "Молоко", "Молочный шоколад");
    }

    @Test
    @DisplayName("ПВ-6. Поиск «мол»; «Бытовая химия»; не скрывать; по названию")
    void pv6() {
        check("мол", "Бытовая химия", false, ProductFilter.SortMode.NAME);
    }

    @Test
    @DisplayName("ПВ-7. Поиск «о»; все категории; не скрывать; по названию")
    void pv7() {
        check("о", ALL, false, ProductFilter.SortMode.NAME,
                "Молоко", "Молочный шоколад", "Мыло", "Яблоки");
    }

    @Test
    @DisplayName("ПВ-8. Поиск «о»; «Продукты»; не скрывать; сначала дорогие")
    void pv8() {
        check("о", "Продукты", false, ProductFilter.SortMode.PRICE_DESC,
                "Молочный шоколад", "Молоко");
    }

    @Test
    @DisplayName("ПВ-9. Поиск «о»; «Бытовая химия»; скрыть купленные; по добавлению")
    void pv9() {
        check("о", "Бытовая химия", true, ProductFilter.SortMode.ADDED, "Мыло");
    }
}
