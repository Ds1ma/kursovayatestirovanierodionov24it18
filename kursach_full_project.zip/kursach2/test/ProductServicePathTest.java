package shoppinglist;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Тесты базисных путей метода ProductService.create() (пункт 2.5.1).
 * Каждый тест проходит ровно один независимый путь тестового графа П1 ... П14.
 * В списке уже есть товар «Молоко»: он нужен для пути с дубликатом.
 */
@DisplayName("Тесты базисных путей метода ProductService.create()")
class ProductServicePathTest {

    private List<Product> existing;

    @BeforeEach
    void setUp() {
        existing = new ArrayList<>();
        existing.add(new Product("Молоко", 2));
    }

    private Product create(String name, String qty, String price, String category) {
        return ProductService.create(existing, name, qty, price, category);
    }

    private void assertError(String expectedMessage, String name, String qty, String price, String category) {
        IllegalArgumentException e = assertThrows(IllegalArgumentException.class,
                () -> create(name, qty, price, category));
        assertEquals(expectedMessage, e.getMessage());
        assertEquals(1, existing.size(), "Список не должен измениться");
    }

    @Test
    @DisplayName("П1 (1–2–16–17). Пустое название")
    void path01_emptyName() {
        assertError("Название товара не может быть пустым!", "", "1", "10", "Продукты");
    }

    @Test
    @DisplayName("П2 (1–2–3–16–17). Название длиннее 50 символов")
    void path02_nameTooLong() {
        assertError("Название слишком длинное (макс. 50 символов).", "а".repeat(51), "1", "10", "Продукты");
    }

    @Test
    @DisplayName("П3 (1–2–3–4–5–16–17). Количество не целое число")
    void path03_quantityNotInteger() {
        assertError("Количество должно быть целым числом!", "Хлеб", "abc", "10", "Продукты");
    }

    @Test
    @DisplayName("П4 (1–2–3–4–5–6–16–17). Количество не больше нуля")
    void path04_quantityNotPositive() {
        assertError("Количество должно быть больше нуля!", "Хлеб", "0", "10", "Продукты");
    }

    @Test
    @DisplayName("П5 (1–2–3–4–5–6–7–16–17). Количество больше 9999")
    void path05_quantityTooBig() {
        assertError("Слишком большое количество (макс. 9999).", "Хлеб", "10000", "10", "Продукты");
    }

    @Test
    @DisplayName("П6 (…–8–9–16–17). Цена не является числом")
    void path06_priceNotNumber() {
        assertError("Цена должна быть числом!", "Хлеб", "1", "abc", "Продукты");
    }

    @Test
    @DisplayName("П7 (…–9–10–16–17). Цена отрицательная")
    void path07_priceNegative() {
        assertError("Цена не может быть отрицательной!", "Хлеб", "1", "-1", "Продукты");
    }

    @Test
    @DisplayName("П8 (…–10–11–16–17). Цена больше 1 000 000")
    void path08_priceTooBig() {
        assertError("Слишком большая цена (макс. 1000000).", "Хлеб", "1", "1000001", "Продукты");
    }

    @Test
    @DisplayName("П9 (…–12–13–16–17). Название категории длиннее 30 символов")
    void path09_categoryTooLong() {
        assertError("Название категории слишком длинное (макс. 30 символов).",
                "Хлеб", "1", "10", "к".repeat(31));
    }

    @Test
    @DisplayName("П10 (…–13–14–16–17). Товар с таким названием уже есть")
    void path10_duplicate() {
        IllegalStateException e = assertThrows(IllegalStateException.class,
                () -> create("молоко", "1", "10", "Продукты"));
        assertEquals("Товар \"молоко\" уже есть в списке!", e.getMessage());
        assertEquals(1, existing.size());
    }

    @Test
    @DisplayName("П11 (1–2–3–4–5–6–7–8–9–10–11–12–13–14–15–17). Все поля заполнены верно")
    void path11_allFieldsValid() {
        Product p = create("Хлеб", "3", "45,5", "Продукты");
        assertEquals("Хлеб", p.getName());
        assertEquals(3, p.getQuantity());
        assertEquals(45.5, p.getPrice(), 0.0001);
        assertEquals("Продукты", p.getCategory());
        assertFalse(p.isBought());
    }

    @Test
    @DisplayName("П12 (1–2–3–4–8–…–15–17). Количество не указано, берётся 1")
    void path12_quantityEmpty() {
        Product p = create("Хлеб", "", "45,5", "Продукты");
        assertEquals(1, p.getQuantity());
        assertEquals(45.5, p.getPrice(), 0.0001);
    }

    @Test
    @DisplayName("П13 (…–8–12–13–14–15–17). Цена не указана, берётся 0")
    void path13_priceEmpty() {
        Product p = create("Хлеб", "3", "", "Продукты");
        assertEquals(3, p.getQuantity());
        assertEquals(0.0, p.getPrice(), 0.0001);
        assertEquals("Продукты", p.getCategory());
    }

    @Test
    @DisplayName("П14 (…–12–14–15–17). Категория не указана, берётся «Без категории»")
    void path14_categoryEmpty() {
        Product p = create("Хлеб", "3", "45,5", "");
        assertEquals(Product.DEFAULT_CATEGORY, p.getCategory());
        assertEquals(45.5, p.getPrice(), 0.0001);
    }
}
