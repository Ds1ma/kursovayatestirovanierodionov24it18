package shoppinglist;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/** Модульные тесты проверки данных и создания/изменения товаров (класс ProductService) */
@DisplayName("Тесты класса ProductService")
class ProductServiceTest {

    private static void assertInvalid(String expectedMessage, Runnable action) {
        IllegalArgumentException e = assertThrows(IllegalArgumentException.class, action::run);
        assertEquals(expectedMessage, e.getMessage());
    }

    // ---------- название ----------

    @Test
    @DisplayName("Название: пробелы по краям убираются")
    void testNameTrimmed() {
        assertEquals("Молоко", ProductService.checkName("  Молоко  "));
    }

    @Test
    @DisplayName("Название: пустое, из пробелов и null недопустимы")
    void testNameEmpty() {
        String message = "Название товара не может быть пустым!";
        assertInvalid(message, () -> ProductService.checkName(""));
        assertInvalid(message, () -> ProductService.checkName("   "));
        assertInvalid(message, () -> ProductService.checkName(null));
    }

    @Test
    @DisplayName("Название: 50 символов допустимо, 51 — нет")
    void testNameLength() {
        String name50 = "б".repeat(50);
        assertEquals(name50, ProductService.checkName(name50));
        assertInvalid("Название слишком длинное (макс. 50 символов).",
                () -> ProductService.checkName(name50 + "б"));
    }

    // ---------- количество ----------

    @Test
    @DisplayName("Количество: пустое поле означает 1")
    void testQuantityEmpty() {
        assertEquals(1, ProductService.parseQuantity(""));
        assertEquals(1, ProductService.parseQuantity("   "));
        assertEquals(1, ProductService.parseQuantity(null));
    }

    @Test
    @DisplayName("Количество: допустимые значения, включая границы 1 и 9999")
    void testQuantityValid() {
        assertEquals(5, ProductService.parseQuantity(" 5 "));
        assertEquals(1, ProductService.parseQuantity("1"));
        assertEquals(9999, ProductService.parseQuantity("9999"));
    }

    @Test
    @DisplayName("Количество: не целое число")
    void testQuantityNotInteger() {
        String message = "Количество должно быть целым числом!";
        assertInvalid(message, () -> ProductService.parseQuantity("abc"));
        assertInvalid(message, () -> ProductService.parseQuantity("2.5"));
        assertInvalid(message, () -> ProductService.parseQuantity("99999999999"));
    }

    @Test
    @DisplayName("Количество: ноль и отрицательные значения")
    void testQuantityNotPositive() {
        String message = "Количество должно быть больше нуля!";
        assertInvalid(message, () -> ProductService.parseQuantity("0"));
        assertInvalid(message, () -> ProductService.parseQuantity("-3"));
    }

    @Test
    @DisplayName("Количество: больше 9999")
    void testQuantityTooBig() {
        assertInvalid("Слишком большое количество (макс. 9999).",
                () -> ProductService.parseQuantity("10000"));
    }

    // ---------- цена ----------

    @Test
    @DisplayName("Цена: пустое поле означает 0")
    void testPriceEmpty() {
        assertEquals(0.0, ProductService.parsePrice(""), 0.0001);
        assertEquals(0.0, ProductService.parsePrice(null), 0.0001);
    }

    @Test
    @DisplayName("Цена: допускаются точка и запятая, значение округляется до копеек")
    void testPriceValid() {
        assertEquals(120.5, ProductService.parsePrice("120.5"), 0.0001);
        assertEquals(120.5, ProductService.parsePrice("120,50"), 0.0001);
        assertEquals(10.46, ProductService.parsePrice("10.456"), 0.0001);
        assertEquals(0.0, ProductService.parsePrice("0"), 0.0001);
        assertEquals(1_000_000.0, ProductService.parsePrice("1000000"), 0.0001);
    }

    @Test
    @DisplayName("Цена: не число")
    void testPriceNotNumber() {
        String message = "Цена должна быть числом!";
        assertInvalid(message, () -> ProductService.parsePrice("abc"));
        assertInvalid(message, () -> ProductService.parsePrice("NaN"));
        assertInvalid(message, () -> ProductService.parsePrice("Infinity"));
    }

    @Test
    @DisplayName("Цена: отрицательная и слишком большая")
    void testPriceRange() {
        assertInvalid("Цена не может быть отрицательной!", () -> ProductService.parsePrice("-1"));
        assertInvalid("Слишком большая цена (макс. 1000000).",
                () -> ProductService.parsePrice("1000000.01"));
    }

    // ---------- категория ----------

    @Test
    @DisplayName("Категория: пустая заменяется категорией по умолчанию, пробелы убираются")
    void testCategory() {
        assertEquals(Product.DEFAULT_CATEGORY, ProductService.checkCategory(null));
        assertEquals(Product.DEFAULT_CATEGORY, ProductService.checkCategory("  "));
        assertEquals("Овощи", ProductService.checkCategory("  Овощи "));
    }

    @Test
    @DisplayName("Категория: 30 символов допустимо, 31 — нет")
    void testCategoryLength() {
        String category30 = "к".repeat(30);
        assertEquals(category30, ProductService.checkCategory(category30));
        assertInvalid("Название категории слишком длинное (макс. 30 символов).",
                () -> ProductService.checkCategory(category30 + "к"));
    }

    // ---------- дубликаты ----------

    @Test
    @DisplayName("Дубликат определяется без учёта регистра")
    void testDuplicate() {
        List<Product> list = new ArrayList<>();
        list.add(new Product("Молоко", 2));

        IllegalStateException e = assertThrows(IllegalStateException.class,
                () -> ProductService.checkDuplicate(list, "молоко", null));
        assertEquals("Товар \"молоко\" уже есть в списке!", e.getMessage());
        ProductService.checkDuplicate(list, "Хлеб", null);   // другого названия нет — ошибки нет
    }

    @Test
    @DisplayName("Сам изменяемый товар не считается дубликатом")
    void testDuplicateIgnoresItself() {
        List<Product> list = new ArrayList<>();
        Product milk = new Product("Молоко", 2);
        list.add(milk);
        ProductService.checkDuplicate(list, "молоко", milk);
    }

    // ---------- create ----------

    @Test
    @DisplayName("create: все поля проверяются и сохраняются в новом товаре")
    void testCreate() {
        List<Product> list = new ArrayList<>();
        Product p = ProductService.create(list, "  Молоко ", " 2 ", "60,5", "Молочные продукты");

        assertEquals("Молоко", p.getName());
        assertEquals(2, p.getQuantity());
        assertEquals(60.5, p.getPrice(), 0.0001);
        assertEquals("Молочные продукты", p.getCategory());
        assertFalse(p.isBought());
        assertEquals(0, list.size(), "create не должен добавлять товар в список");
    }

    @Test
    @DisplayName("create: пустые количество, цена и категория дают значения по умолчанию")
    void testCreateDefaults() {
        Product p = ProductService.create(new ArrayList<Product>(), "Сыр", "", "", "");
        assertEquals(1, p.getQuantity());
        assertEquals(0.0, p.getPrice(), 0.0001);
        assertEquals(Product.DEFAULT_CATEGORY, p.getCategory());
    }

    @Test
    @DisplayName("create: при нескольких ошибках сообщается первая — по названию")
    void testCreateReportsFirstError() {
        assertInvalid("Название товара не может быть пустым!",
                () -> ProductService.create(new ArrayList<Product>(), "", "abc", "abc", "abc"));
        assertInvalid("Количество должно быть целым числом!",
                () -> ProductService.create(new ArrayList<Product>(), "Хлеб", "abc", "abc", ""));
        assertInvalid("Цена должна быть числом!",
                () -> ProductService.create(new ArrayList<Product>(), "Хлеб", "1", "abc", ""));
    }

    @Test
    @DisplayName("create: дубликат вызывает IllegalStateException")
    void testCreateDuplicate() {
        List<Product> list = new ArrayList<>();
        list.add(new Product("Молоко", 2));
        assertThrows(IllegalStateException.class,
                () -> ProductService.create(list, "МОЛОКО", "1", "", ""));
    }

    // ---------- update ----------

    @Test
    @DisplayName("update: изменяет все поля товара")
    void testUpdate() {
        List<Product> list = new ArrayList<>();
        Product p = new Product("Молоко", 2);
        list.add(p);

        ProductService.update(p, list, "Кефир", "3", "75", "Молочные продукты");

        assertEquals("Кефир", p.getName());
        assertEquals(3, p.getQuantity());
        assertEquals(75.0, p.getPrice(), 0.0001);
        assertEquals("Молочные продукты", p.getCategory());
    }

    @Test
    @DisplayName("update: при ошибке товар остаётся без изменений")
    void testUpdateKeepsProductOnError() {
        List<Product> list = new ArrayList<>();
        Product p = new Product("Молоко", 2, "Продукты", 60);
        list.add(p);

        assertInvalid("Количество должно быть больше нуля!",
                () -> ProductService.update(p, list, "Кефир", "0", "75", "Напитки"));

        assertEquals("Молоко", p.getName());
        assertEquals(2, p.getQuantity());
        assertEquals(60.0, p.getPrice(), 0.0001);
        assertEquals("Продукты", p.getCategory());
    }

    @Test
    @DisplayName("update: нельзя дать товару название другого товара")
    void testUpdateDuplicate() {
        List<Product> list = new ArrayList<>();
        Product milk = new Product("Молоко", 2);
        Product bread = new Product("Хлеб", 1);
        list.add(milk);
        list.add(bread);

        assertThrows(IllegalStateException.class,
                () -> ProductService.update(bread, list, "молоко", "1", "", ""));
        assertEquals("Хлеб", bread.getName());
    }

    @Test
    @DisplayName("update: можно изменить регистр собственного названия")
    void testUpdateOwnNameChangeCase() {
        List<Product> list = new ArrayList<>();
        Product milk = new Product("Молоко", 2);
        list.add(milk);

        ProductService.update(milk, list, "МОЛОКО", "2", "", "");
        assertEquals("МОЛОКО", milk.getName());
    }
}
